# Infrastructure as Code

Terraform configuration for AWS deployment.

## Environments

- `dev` - Development environment
- `staging` - Staging environment
- `prod` - Production environment

## Resources (To Be Configured)

- VPC and networking
- ECS/Fargate for backend services
- RDS for PostgreSQL (or use Supabase)
- ElastiCache for Redis
- S3 for static assets
- CloudFront for CDN
- Route53 for DNS
- Application Load Balancer
- IAM roles and policies

## Usage

```bash
terraform init
terraform plan -var="environment=dev"
terraform apply -var="environment=dev"
```
