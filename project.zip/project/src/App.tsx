import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Coaches from './pages/Coaches';
import Bookings from './pages/Bookings';
import Tournaments from './pages/Tournaments';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
        <nav className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16 items-center">
              <Link to="/" className="text-2xl font-bold text-green-600">
                🎾 Tennis Platform
              </Link>
              <div className="flex gap-6">
                <Link
                  to="/coaches"
                  className="px-4 py-2 text-gray-700 hover:text-green-600 font-medium"
                >
                  Coaches
                </Link>
                <Link
                  to="/bookings"
                  className="px-4 py-2 text-gray-700 hover:text-green-600 font-medium"
                >
                  Bookings
                </Link>
                <Link
                  to="/tournaments"
                  className="px-4 py-2 text-gray-700 hover:text-green-600 font-medium"
                >
                  Tournaments
                </Link>
                <a
                  href="http://localhost:3001/api"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  API Docs
                </a>
              </div>
            </div>
          </div>
        </nav>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/coaches" element={<Coaches />} />
          <Route path="/bookings" element={<Bookings />} />
          <Route path="/tournaments" element={<Tournaments />} />
        </Routes>

        <footer className="bg-white border-t mt-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-gray-600">
            <p>Tennis Platform - Full-Stack Skeleton Project</p>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;
