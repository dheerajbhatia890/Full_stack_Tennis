import { useState } from 'react';
import { MapPin, Clock, Calendar, Check } from 'lucide-react';

interface Club {
  id: string;
  name: string;
  location: string;
  courts: Court[];
}

interface Court {
  id: string;
  name: string;
  surface: string;
  isIndoor: boolean;
  rate: number;
}

interface TimeSlot {
  time: string;
  available: boolean;
}

export default function Bookings() {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedClub, setSelectedClub] = useState<string>('');
  const [selectedCourt, setSelectedCourt] = useState<string>('');

  const clubs: Club[] = [
    {
      id: '1',
      name: 'Downtown Tennis Center',
      location: 'Manhattan, NY',
      courts: [
        { id: '1', name: 'Court 1', surface: 'Hard', isIndoor: true, rate: 50 },
        { id: '2', name: 'Court 2', surface: 'Hard', isIndoor: true, rate: 50 },
        { id: '3', name: 'Court 3', surface: 'Clay', isIndoor: false, rate: 45 },
      ],
    },
    {
      id: '2',
      name: 'Riverside Tennis Club',
      location: 'Brooklyn, NY',
      courts: [
        { id: '4', name: 'Court A', surface: 'Hard', isIndoor: false, rate: 40 },
        { id: '5', name: 'Court B', surface: 'Grass', isIndoor: false, rate: 55 },
      ],
    },
    {
      id: '3',
      name: 'Elite Tennis Academy',
      location: 'Queens, NY',
      courts: [
        { id: '6', name: 'Court 1', surface: 'Hard', isIndoor: true, rate: 60 },
        { id: '7', name: 'Court 2', surface: 'Hard', isIndoor: true, rate: 60 },
        { id: '8', name: 'Court 3', surface: 'Clay', isIndoor: true, rate: 65 },
        { id: '9', name: 'Court 4', surface: 'Clay', isIndoor: true, rate: 65 },
      ],
    },
  ];

  const timeSlots: TimeSlot[] = [
    { time: '8:00 AM', available: true },
    { time: '9:00 AM', available: true },
    { time: '10:00 AM', available: false },
    { time: '11:00 AM', available: true },
    { time: '12:00 PM', available: true },
    { time: '1:00 PM', available: false },
    { time: '2:00 PM', available: true },
    { time: '3:00 PM', available: true },
    { time: '4:00 PM', available: true },
    { time: '5:00 PM', available: false },
    { time: '6:00 PM', available: true },
    { time: '7:00 PM', available: true },
  ];

  const selectedClubData = clubs.find((club) => club.id === selectedClub);
  const selectedCourtData = selectedClubData?.courts.find((court) => court.id === selectedCourt);

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Court Bookings</h1>
        <p className="text-xl text-gray-600">Reserve tennis courts at top clubs</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold mb-4">Select Club</h2>
            <div className="space-y-3">
              {clubs.map((club) => (
                <div
                  key={club.id}
                  onClick={() => {
                    setSelectedClub(club.id);
                    setSelectedCourt('');
                  }}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                    selectedClub === club.id
                      ? 'border-green-600 bg-green-50'
                      : 'border-gray-200 hover:border-green-300'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-lg">{club.name}</h3>
                      <div className="flex items-center gap-2 text-gray-600 mt-1">
                        <MapPin className="w-4 h-4" />
                        <span className="text-sm">{club.location}</span>
                      </div>
                    </div>
                    {selectedClub === club.id && (
                      <Check className="w-6 h-6 text-green-600" />
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mt-2">{club.courts.length} courts available</p>
                </div>
              ))}
            </div>
          </div>

          {selectedClub && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold mb-4">Select Court</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {selectedClubData?.courts.map((court) => (
                  <div
                    key={court.id}
                    onClick={() => setSelectedCourt(court.id)}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                      selectedCourt === court.id
                        ? 'border-green-600 bg-green-50'
                        : 'border-gray-200 hover:border-green-300'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold">{court.name}</h3>
                      {selectedCourt === court.id && (
                        <Check className="w-5 h-5 text-green-600" />
                      )}
                    </div>
                    <div className="space-y-1 text-sm text-gray-600">
                      <p>{court.surface} Court</p>
                      <p>{court.isIndoor ? 'Indoor' : 'Outdoor'}</p>
                      <p className="font-semibold text-green-600">${court.rate}/hour</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {selectedCourt && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold mb-4">Select Time Slot</h2>
              <div className="grid grid-cols-3 gap-3">
                {timeSlots.map((slot) => (
                  <button
                    key={slot.time}
                    disabled={!slot.available}
                    className={`p-3 rounded-lg font-medium transition-colors ${
                      slot.available
                        ? 'bg-green-100 text-green-700 hover:bg-green-200'
                        : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    {slot.time}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 h-fit sticky top-6">
          <h2 className="text-xl font-bold mb-4">Booking Summary</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Date
              </label>
              <div className="flex items-center gap-2 p-3 border rounded-lg">
                <Calendar className="w-5 h-5 text-gray-400" />
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="flex-1 outline-none"
                />
              </div>
            </div>

            {selectedClubData && (
              <div className="border-t pt-4">
                <p className="text-sm text-gray-600">Club</p>
                <p className="font-semibold">{selectedClubData.name}</p>
              </div>
            )}

            {selectedCourtData && (
              <div className="border-t pt-4">
                <p className="text-sm text-gray-600">Court</p>
                <p className="font-semibold">{selectedCourtData.name}</p>
                <p className="text-sm text-gray-600 mt-1">
                  {selectedCourtData.surface} • {selectedCourtData.isIndoor ? 'Indoor' : 'Outdoor'}
                </p>
              </div>
            )}

            {selectedCourtData && (
              <div className="border-t pt-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Duration</span>
                  <span className="font-semibold">1 hour</span>
                </div>
                <div className="flex justify-between items-center text-lg font-bold">
                  <span>Total</span>
                  <span className="text-green-600">${selectedCourtData.rate}</span>
                </div>
              </div>
            )}

            <button
              disabled={!selectedCourt}
              className={`w-full py-3 rounded-lg font-semibold transition-colors ${
                selectedCourt
                  ? 'bg-green-600 text-white hover:bg-green-700'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              Confirm Booking
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}
