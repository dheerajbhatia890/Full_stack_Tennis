import { Search, Users, Trophy, MapPin, Code, Server, Smartphone } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-16">
        <h1 className="text-5xl font-bold text-gray-900 mb-4">
          Full-Stack Tennis Platform
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Complete skeleton with backend, web frontend, mobile app, database, auth, and RBAC
        </p>
        <div className="inline-flex gap-4">
          <a
            href="http://localhost:3000"
            target="_blank"
            rel="noopener noreferrer"
            className="px-8 py-4 bg-green-600 text-white text-lg font-semibold rounded-lg hover:bg-green-700"
          >
            Launch Web App
          </a>
          <a
            href="http://localhost:3001/api"
            target="_blank"
            rel="noopener noreferrer"
            className="px-8 py-4 bg-gray-800 text-white text-lg font-semibold rounded-lg hover:bg-gray-900"
          >
            View API Docs
          </a>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8 mb-16">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <Server className="w-12 h-12 text-green-600 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Backend API</h3>
          <p className="text-gray-600 mb-4">
            NestJS backend with Supabase, JWT auth, and REST API
          </p>
          <code className="text-sm bg-gray-100 px-2 py-1 rounded">
            cd apps/backend && npm run start:dev
          </code>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <Code className="w-12 h-12 text-green-600 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Web Frontend</h3>
          <p className="text-gray-600 mb-4">
            Next.js 14 with App Router, TailwindCSS, and authentication
          </p>
          <code className="text-sm bg-gray-100 px-2 py-1 rounded">
            cd apps/web && npm run dev
          </code>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <Smartphone className="w-12 h-12 text-green-600 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Mobile App</h3>
          <p className="text-gray-600 mb-4">
            React Native with Expo, navigation, and API integration
          </p>
          <code className="text-sm bg-gray-100 px-2 py-1 rounded">
            cd apps/mobile && npm start
          </code>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-8 mb-8">
        <h2 className="text-2xl font-bold mb-6">Platform Features</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <Link to="/coaches" className="flex gap-4 hover:bg-gray-50 p-4 rounded-lg transition-colors">
            <Search className="w-6 h-6 text-green-600 flex-shrink-0" />
            <div>
              <h4 className="font-semibold mb-1">Coach Directory</h4>
              <p className="text-gray-600 text-sm">Search and book professional tennis coaches</p>
            </div>
          </Link>
          <div className="flex gap-4 p-4">
            <Users className="w-6 h-6 text-green-600 flex-shrink-0" />
            <div>
              <h4 className="font-semibold mb-1">Player Profiles</h4>
              <p className="text-gray-600 text-sm">Complete profiles with ratings and match history</p>
            </div>
          </div>
          <Link to="/bookings" className="flex gap-4 hover:bg-gray-50 p-4 rounded-lg transition-colors">
            <MapPin className="w-6 h-6 text-green-600 flex-shrink-0" />
            <div>
              <h4 className="font-semibold mb-1">Court Bookings</h4>
              <p className="text-gray-600 text-sm">Reserve courts at clubs with real-time availability</p>
            </div>
          </Link>
          <Link to="/tournaments" className="flex gap-4 hover:bg-gray-50 p-4 rounded-lg transition-colors">
            <Trophy className="w-6 h-6 text-green-600 flex-shrink-0" />
            <div>
              <h4 className="font-semibold mb-1">Tournaments & Ladders</h4>
              <p className="text-gray-600 text-sm">Compete in organized events and climb rankings</p>
            </div>
          </Link>
        </div>
      </div>

      <div className="bg-gray-800 text-white rounded-lg shadow-md p-8">
        <h2 className="text-2xl font-bold mb-4">Tech Stack</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div>
            <h4 className="font-semibold mb-2 text-green-400">Backend</h4>
            <ul className="text-sm space-y-1 text-gray-300">
              <li>NestJS (TypeScript)</li>
              <li>Supabase (PostgreSQL)</li>
              <li>JWT Authentication</li>
              <li>Role-Based Access Control</li>
              <li>REST API + Swagger</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-2 text-green-400">Frontend</h4>
            <ul className="text-sm space-y-1 text-gray-300">
              <li>Next.js 14 (App Router)</li>
              <li>React 18</li>
              <li>TailwindCSS</li>
              <li>Axios API Client</li>
              <li>TypeScript</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-2 text-green-400">Mobile</h4>
            <ul className="text-sm space-y-1 text-gray-300">
              <li>React Native</li>
              <li>Expo</li>
              <li>React Navigation</li>
              <li>AsyncStorage</li>
              <li>TypeScript</li>
            </ul>
          </div>
        </div>
      </div>
    </main>
  );
}
