import { useState } from 'react';
import { Search, MapPin, Star, Calendar, DollarSign } from 'lucide-react';

interface Coach {
  id: string;
  name: string;
  rating: number;
  hourlyRate: number;
  specialties: string[];
  location: string;
  experience: number;
  imageUrl: string;
}

export default function Coaches() {
  const [searchQuery, setSearchQuery] = useState('');

  const coaches: Coach[] = [
    {
      id: '1',
      name: 'Sarah Johnson',
      rating: 4.9,
      hourlyRate: 75,
      specialties: ['Singles', 'Advanced Technique', 'Competition Prep'],
      location: 'New York, NY',
      experience: 12,
      imageUrl: 'https://images.pexels.com/photos/3621104/pexels-photo-3621104.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      id: '2',
      name: 'Michael Chen',
      rating: 4.8,
      hourlyRate: 65,
      specialties: ['Beginners', 'Junior Development', 'Footwork'],
      location: 'Los Angeles, CA',
      experience: 8,
      imageUrl: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      id: '3',
      name: 'Emma Rodriguez',
      rating: 5.0,
      hourlyRate: 85,
      specialties: ['Doubles Strategy', 'Mental Game', 'Tournament Play'],
      location: 'Miami, FL',
      experience: 15,
      imageUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      id: '4',
      name: 'David Park',
      rating: 4.7,
      hourlyRate: 70,
      specialties: ['Serve & Volley', 'Clay Court', 'Fitness'],
      location: 'Austin, TX',
      experience: 10,
      imageUrl: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
  ];

  const filteredCoaches = coaches.filter(
    (coach) =>
      coach.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      coach.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      coach.specialties.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Coach Directory</h1>
        <p className="text-xl text-gray-600">Find and book professional tennis coaches</p>
      </div>

      <div className="mb-8">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search by name, location, or specialty..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {filteredCoaches.map((coach) => (
          <div key={coach.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
            <div className="flex">
              <img
                src={coach.imageUrl}
                alt={coach.name}
                className="w-48 h-full object-cover"
              />
              <div className="p-6 flex-1">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-bold text-gray-900">{coach.name}</h3>
                  <div className="flex items-center gap-1">
                    <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                    <span className="font-semibold">{coach.rating}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-gray-600 mb-3">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">{coach.location}</span>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {coach.specialties.map((specialty) => (
                    <span
                      key={specialty}
                      className="px-3 py-1 bg-green-100 text-green-700 text-xs rounded-full"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>{coach.experience} years</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-4 h-4" />
                      <span>${coach.hourlyRate}/hr</span>
                    </div>
                  </div>
                  <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                    Book Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredCoaches.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-600 text-lg">No coaches found matching your search.</p>
        </div>
      )}
    </main>
  );
}
