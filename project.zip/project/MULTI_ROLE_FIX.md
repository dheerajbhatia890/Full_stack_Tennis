# 🔧 Multi-Role Onboarding Fix

## Problem
After completing the player profile setup, the app redirects to login instead of continuing to the coach profile setup.

## Root Cause
The Supabase auth session wasn't configured with proper persistence options, causing the session to be lost during page navigation.

## ✅ Solution Applied

### Updated File: `apps/web/lib/supabase.ts`

Added auth persistence configuration to the Supabase client:

```typescript
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,        // Keep session across page reloads
    autoRefreshToken: true,       // Auto-refresh expired tokens
    detectSessionInUrl: true,     // Detect auth callback URLs
    storageKey: 'tennis-platform-auth',  // Custom storage key
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
  }
});
```

### Enhanced: `apps/web/app/onboarding/player/page.tsx`

Added better session checking and debugging:
- Checks both `getUser()` and `getSession()` 
- Logs navigation steps for debugging
- Saves progress before redirecting on session loss

## 🚀 How to Apply the Fix

### Option 1: Replace the file (Easiest)

1. Extract the updated zip file
2. Replace your `apps/web/lib/supabase.ts` with the new one
3. Replace your `apps/web/app/onboarding/player/page.tsx` with the new one
4. Restart your dev server

### Option 2: Manual Update

**File 1: `apps/web/lib/supabase.ts`**

Replace:
```typescript
export const supabase = createClient(supabaseUrl, supabaseAnonKey);
```

With:
```typescript
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storageKey: 'tennis-platform-auth',
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
  }
});
```

**File 2: `apps/web/app/onboarding/player/page.tsx`**

In the `handleSubmit` function, after `setLoading(true);`, add:

```typescript
// Check session first
const { data: { session } } = await supabase.auth.getSession();
console.log('Current session:', session ? 'Active' : 'No session');
```

And update the session check:
```typescript
const { data: { user: authUser } } = await supabase.auth.getUser();

if (!authUser || !session) {
  console.error('Session lost - User:', authUser?.id, 'Session:', session?.access_token);
  setError('Your session has expired. Please log in again.');
  setLoading(false);
  // Store current progress before redirecting
  localStorage.setItem('onboarding_progress', JSON.stringify({
    step: 'player',
    data: { ageGroup, yearsPlaying, skillLevel, gameDescription, city, state, profileImage }
  }));
  router.push('/login');
  return;
}
```

## 🧪 Testing the Fix

1. **Sign up** for a new account
2. **Select both "Player" and "Coach"** roles
3. **Complete the Player form** and submit
4. **You should now see** the Coach setup page (not login)
5. **Complete the Coach form**
6. **You should now see** the dashboard

## 🔍 Debugging

If issues persist, open your browser's console (F12) and look for these logs:

```
Current session: Active
Creating player profile for user: [user-id]
Selected roles: ["Player", "Coach"]
Player profile created successfully
Coach profile exists: No
Navigating to coach setup...
```

If you see "No session", that indicates the session is being lost somewhere.

## 📝 Additional Notes

### Why This Happens

By default, Supabase uses "local" storage but doesn't explicitly configure persistence. In some browsers or configurations, this can cause the session to be lost during navigation, especially with Next.js's client-side routing.

### What the Fix Does

1. **persistSession: true** - Explicitly enables session persistence
2. **autoRefreshToken: true** - Automatically refreshes tokens before expiry
3. **detectSessionInUrl: true** - Handles OAuth callback URLs properly
4. **Custom storageKey** - Prevents conflicts with other apps
5. **Explicit localStorage** - Ensures browser localStorage is used

### Other Affected Flows

This fix also improves:
- Login persistence across page reloads
- Session maintenance during navigation
- OAuth authentication flows
- Token refresh handling

## ✅ Expected Behavior After Fix

**Multi-Role Flow:**
```
Register → Select Roles → Player Setup → Coach Setup → Dashboard
                          ✅ No login redirect here anymore!
```

**Single Role Flow:**
```
Register → Select Role → Profile Setup → Dashboard
```

## 🎯 Success!

After applying this fix, the multi-role onboarding flow will work correctly. The session will persist across page navigations, and users won't be logged out between profile setups.

---

**Need Help?** Check the browser console for debug logs or reach out with the specific error message.
