/*
  # Add INSERT policy for clubs table

  1. Changes
    - Add policy to allow authenticated users to create clubs where they are the admin
  
  2. Security
    - Users can only create clubs where they are set as the admin_user_id
*/

CREATE POLICY "Users can create clubs as admin"
  ON clubs
  FOR INSERT
  TO authenticated
  WITH CHECK (admin_user_id = auth.uid());
