/*
  # Add INSERT policy for users table

  1. Security Changes
    - Add policy to allow authenticated users to insert their own user record during registration
    - This is needed for the registration flow where Supabase Auth creates the auth user,
      and then the application creates the corresponding users table record
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' 
    AND policyname = 'Users can create own user record'
  ) THEN
    CREATE POLICY "Users can create own user record"
      ON users
      FOR INSERT
      TO authenticated
      WITH CHECK (id = auth.uid());
  END IF;
END $$;
