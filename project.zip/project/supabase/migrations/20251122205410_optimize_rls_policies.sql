/*
  # Optimize RLS Policies for Performance

  1. Performance Optimization
    - Replace auth.uid() with (select auth.uid()) in all RLS policies
    - This prevents re-evaluation for each row and significantly improves performance
    
  2. Tables Updated
    - users
    - player_profiles
    - coach_profiles
    - clubs
    - courts
    - bookings
    - notifications
    - chat_messages
    - reviews
    - payouts
    - package_credits
*/

-- Users table
DROP POLICY IF EXISTS "Users can view own profile" ON public.users;
DROP POLICY IF EXISTS "Users can update own profile" ON public.users;

CREATE POLICY "Users can view own profile"
  ON public.users
  FOR SELECT
  TO authenticated
  USING (id = (select auth.uid()));

CREATE POLICY "Users can update own profile"
  ON public.users
  FOR UPDATE
  TO authenticated
  USING (id = (select auth.uid()))
  WITH CHECK (id = (select auth.uid()));

-- Player Profiles
DROP POLICY IF EXISTS "Users can create own player profile" ON public.player_profiles;
DROP POLICY IF EXISTS "Users can update own player profile" ON public.player_profiles;

CREATE POLICY "Users can create own player profile"
  ON public.player_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own player profile"
  ON public.player_profiles
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- Coach Profiles
DROP POLICY IF EXISTS "Users can create own coach profile" ON public.coach_profiles;
DROP POLICY IF EXISTS "Coaches can update own profile" ON public.coach_profiles;

CREATE POLICY "Users can create own coach profile"
  ON public.coach_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Coaches can update own profile"
  ON public.coach_profiles
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- Clubs
DROP POLICY IF EXISTS "Club admins can update own club" ON public.clubs;

CREATE POLICY "Club admins can update own club"
  ON public.clubs
  FOR UPDATE
  TO authenticated
  USING (admin_user_id = (select auth.uid()))
  WITH CHECK (admin_user_id = (select auth.uid()));

-- Courts
DROP POLICY IF EXISTS "Club admins can insert courts" ON public.courts;
DROP POLICY IF EXISTS "Club admins can update courts" ON public.courts;
DROP POLICY IF EXISTS "Club admins can delete courts" ON public.courts;

CREATE POLICY "Club admins can insert courts"
  ON public.courts
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.clubs
      WHERE clubs.id = courts.club_id
      AND clubs.admin_user_id = (select auth.uid())
    )
  );

CREATE POLICY "Club admins can update courts"
  ON public.courts
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.clubs
      WHERE clubs.id = courts.club_id
      AND clubs.admin_user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.clubs
      WHERE clubs.id = courts.club_id
      AND clubs.admin_user_id = (select auth.uid())
    )
  );

CREATE POLICY "Club admins can delete courts"
  ON public.courts
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.clubs
      WHERE clubs.id = courts.club_id
      AND clubs.admin_user_id = (select auth.uid())
    )
  );

-- Bookings
DROP POLICY IF EXISTS "Users can view own bookings" ON public.bookings;
DROP POLICY IF EXISTS "Players can create bookings" ON public.bookings;
DROP POLICY IF EXISTS "Users can update own bookings" ON public.bookings;

CREATE POLICY "Users can view own bookings"
  ON public.bookings
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = bookings.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
    OR
    EXISTS (
      SELECT 1 FROM public.coach_profiles
      WHERE coach_profiles.id = bookings.coach_id
      AND coach_profiles.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Players can create bookings"
  ON public.bookings
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = bookings.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Users can update own bookings"
  ON public.bookings
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = bookings.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = bookings.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );

-- Notifications
DROP POLICY IF EXISTS "Users can view own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON public.notifications;

CREATE POLICY "Users can view own notifications"
  ON public.notifications
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can update own notifications"
  ON public.notifications
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- Chat Messages
DROP POLICY IF EXISTS "Users can view own messages" ON public.chat_messages;
DROP POLICY IF EXISTS "Users can send messages" ON public.chat_messages;

CREATE POLICY "Users can view own messages"
  ON public.chat_messages
  FOR SELECT
  TO authenticated
  USING (sender_id = (select auth.uid()) OR recipient_id = (select auth.uid()));

CREATE POLICY "Users can send messages"
  ON public.chat_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (sender_id = (select auth.uid()));

-- Reviews
DROP POLICY IF EXISTS "Users can create reviews" ON public.reviews;

CREATE POLICY "Users can create reviews"
  ON public.reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (reviewer_id = (select auth.uid()));

-- Payouts
DROP POLICY IF EXISTS "Coaches can view own payouts" ON public.payouts;

CREATE POLICY "Coaches can view own payouts"
  ON public.payouts
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.coach_profiles
      WHERE coach_profiles.id = payouts.coach_id
      AND coach_profiles.user_id = (select auth.uid())
    )
  );

-- Package Credits
DROP POLICY IF EXISTS "Users can view own package credits" ON public.package_credits;

CREATE POLICY "Users can view own package credits"
  ON public.package_credits
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = package_credits.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );
