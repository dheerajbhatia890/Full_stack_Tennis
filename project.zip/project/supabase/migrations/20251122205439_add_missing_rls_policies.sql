/*
  # Add Missing RLS Policies

  1. Tables with Missing Policies
    - court_schedules
    - ladder_members
    - tournament_participants
    - zone_enrollments
    - zones
    
  2. Security
    - All policies check authentication and ownership/membership
    - Restrictive by default - users can only access data they own or are members of
    - Public read access for zones (as they are generally public information)
*/

-- Court Schedules
CREATE POLICY "Anyone can view court schedules"
  ON public.court_schedules
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Club admins can manage court schedules"
  ON public.court_schedules
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.courts
      JOIN public.clubs ON clubs.id = courts.club_id
      WHERE courts.id = court_schedules.court_id
      AND clubs.admin_user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.courts
      JOIN public.clubs ON clubs.id = courts.club_id
      WHERE courts.id = court_schedules.court_id
      AND clubs.admin_user_id = (select auth.uid())
    )
  );

-- Zones (public information)
CREATE POLICY "Anyone can view zones"
  ON public.zones
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage zones"
  ON public.zones
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.users
      WHERE users.id = (select auth.uid())
      AND users.role = 'SuperAdmin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.users
      WHERE users.id = (select auth.uid())
      AND users.role = 'SuperAdmin'
    )
  );

-- Zone Enrollments
CREATE POLICY "Users can view own zone enrollments"
  ON public.zone_enrollments
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = zone_enrollments.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Players can enroll in zones"
  ON public.zone_enrollments
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = zone_enrollments.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Players can update own enrollments"
  ON public.zone_enrollments
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = zone_enrollments.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = zone_enrollments.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );

-- Ladder Members
CREATE POLICY "Anyone can view ladder members"
  ON public.ladder_members
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Players can join ladders"
  ON public.ladder_members
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = ladder_members.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Players can update own ladder membership"
  ON public.ladder_members
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = ladder_members.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = ladder_members.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Players can leave ladders"
  ON public.ladder_members
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = ladder_members.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );

-- Tournament Participants
CREATE POLICY "Anyone can view tournament participants"
  ON public.tournament_participants
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Players can register for tournaments"
  ON public.tournament_participants
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = tournament_participants.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Players can update own tournament registration"
  ON public.tournament_participants
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = tournament_participants.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = tournament_participants.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Players can withdraw from tournaments"
  ON public.tournament_participants
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.player_profiles
      WHERE player_profiles.id = tournament_participants.player_id
      AND player_profiles.user_id = (select auth.uid())
    )
  );
