/*
  # Add Multi-Role Support and Enhanced User Profiles

  ## Overview
  This migration extends the platform to support users having multiple roles (Player, Coach, Club Admin)
  and adds comprehensive profile fields for each role type.

  ## Changes Made

  ### 1. Users Table Updates
    - Add `roles` array column to support multiple roles per user
    - Add `first_name` and `last_name` to users table
    - Add `profile_image_url` shared across all profiles
    - Add `onboarding_completed` flag to track profile setup

  ### 2. Player Profiles Enhancements
    - Add `age_group` (Kids, Juniors, Adults, Seniors)
    - Add `skill_level` (Beginner, Advanced Beginner, Intermediate, Advanced, Professional)
    - Add `game_description` text field
    - Add `city` and `state` location fields
    - Add `preferred_courts` array field

  ### 3. Coach Profiles Enhancements
    - Add `years_experience` numeric field
    - Add `coach_type` (Full-Time, Part-Time)
    - Add `player_types_coached` array (Kids, Juniors, Adults, etc.)
    - Add `levels_taught` array
    - Add `certification_proof_url` for document upload
    - Add `coaching_experience_description` text field
    - Add `teaching_style_description` text field
    - Add `achievements` text field
    - Add `featured_in` text field

  ### 4. New Table: Coach Training Locations
    - `id` (uuid, primary key)
    - `coach_id` (uuid, foreign key to coach_profiles)
    - `location_name` (text)
    - `address_line1` (text)
    - `address_line2` (text)
    - `city` (text)
    - `state` (text)
    - `zip_code` (text)
    - `travel_radius` (numeric, miles)
    - `google_maps_link` (text)
    - `is_preferred` (boolean)

  ### 5. Security
    - Enable RLS on new tables
    - Add appropriate policies for coaches to manage their locations
    - Update existing policies to work with multi-role system

  ## Important Notes
  - Users can now have multiple roles simultaneously
  - Profile setup is tracked with `onboarding_completed` flag
  - All existing data is preserved
  - Photo upload URL is stored at user level and shared across profiles
*/

-- Add new columns to users table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'first_name'
  ) THEN
    ALTER TABLE users ADD COLUMN first_name text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'last_name'
  ) THEN
    ALTER TABLE users ADD COLUMN last_name text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'profile_image_url'
  ) THEN
    ALTER TABLE users ADD COLUMN profile_image_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'roles'
  ) THEN
    ALTER TABLE users ADD COLUMN roles text[] DEFAULT '{}';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'onboarding_completed'
  ) THEN
    ALTER TABLE users ADD COLUMN onboarding_completed boolean DEFAULT false;
  END IF;
END $$;

-- Enhance player_profiles table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'player_profiles' AND column_name = 'age_group'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN age_group text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'player_profiles' AND column_name = 'skill_level'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN skill_level text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'player_profiles' AND column_name = 'game_description'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN game_description text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'player_profiles' AND column_name = 'city'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN city text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'player_profiles' AND column_name = 'state'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN state text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'player_profiles' AND column_name = 'preferred_courts'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN preferred_courts text[] DEFAULT '{}';
  END IF;
END $$;

-- Enhance coach_profiles table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'coach_profiles' AND column_name = 'years_experience'
  ) THEN
    ALTER TABLE coach_profiles ADD COLUMN years_experience numeric;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'coach_profiles' AND column_name = 'coach_type'
  ) THEN
    ALTER TABLE coach_profiles ADD COLUMN coach_type text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'coach_profiles' AND column_name = 'player_types_coached'
  ) THEN
    ALTER TABLE coach_profiles ADD COLUMN player_types_coached text[] DEFAULT '{}';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'coach_profiles' AND column_name = 'levels_taught'
  ) THEN
    ALTER TABLE coach_profiles ADD COLUMN levels_taught text[] DEFAULT '{}';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'coach_profiles' AND column_name = 'certification_proof_url'
  ) THEN
    ALTER TABLE coach_profiles ADD COLUMN certification_proof_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'coach_profiles' AND column_name = 'coaching_experience_description'
  ) THEN
    ALTER TABLE coach_profiles ADD COLUMN coaching_experience_description text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'coach_profiles' AND column_name = 'teaching_style_description'
  ) THEN
    ALTER TABLE coach_profiles ADD COLUMN teaching_style_description text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'coach_profiles' AND column_name = 'achievements'
  ) THEN
    ALTER TABLE coach_profiles ADD COLUMN achievements text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'coach_profiles' AND column_name = 'featured_in'
  ) THEN
    ALTER TABLE coach_profiles ADD COLUMN featured_in text;
  END IF;
END $$;

-- Create coach_training_locations table
CREATE TABLE IF NOT EXISTS coach_training_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  coach_id uuid NOT NULL REFERENCES coach_profiles(id) ON DELETE CASCADE,
  location_name text NOT NULL,
  address_line1 text NOT NULL,
  address_line2 text,
  city text NOT NULL,
  state text NOT NULL,
  zip_code text NOT NULL,
  travel_radius numeric,
  google_maps_link text,
  is_preferred boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on coach_training_locations
ALTER TABLE coach_training_locations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for coach_training_locations
CREATE POLICY "Anyone can view coach training locations"
  ON coach_training_locations
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Coaches can insert own training locations"
  ON coach_training_locations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM coach_profiles
      WHERE coach_profiles.id = coach_training_locations.coach_id
      AND coach_profiles.user_id = auth.uid()
    )
  );

CREATE POLICY "Coaches can update own training locations"
  ON coach_training_locations
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM coach_profiles
      WHERE coach_profiles.id = coach_training_locations.coach_id
      AND coach_profiles.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM coach_profiles
      WHERE coach_profiles.id = coach_training_locations.coach_id
      AND coach_profiles.user_id = auth.uid()
    )
  );

CREATE POLICY "Coaches can delete own training locations"
  ON coach_training_locations
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM coach_profiles
      WHERE coach_profiles.id = coach_training_locations.coach_id
      AND coach_profiles.user_id = auth.uid()
    )
  );

-- Create index on coach_id for better query performance
CREATE INDEX IF NOT EXISTS idx_coach_training_locations_coach_id 
ON coach_training_locations(coach_id);
