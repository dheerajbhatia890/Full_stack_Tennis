/*
  # Move PostGIS Extension to Extensions Schema

  1. Schema Management
    - Create extensions schema if it doesn't exist
    - Move PostGIS extension from public to extensions schema
    - This is a best practice to keep public schema clean
    
  2. Important Notes
    - The spatial_ref_sys table will remain in public schema (PostGIS requirement)
    - RLS is not typically enabled on spatial_ref_sys as it's reference data
    - All PostGIS functions will be available from the extensions schema
*/

-- Create extensions schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS extensions;

-- Move PostGIS to extensions schema
-- Note: We need to drop and recreate the extension in the new schema
DO $$
BEGIN
  -- Check if PostGIS exists in public schema
  IF EXISTS (
    SELECT 1 FROM pg_extension 
    WHERE extname = 'postgis' 
    AND extnamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'public')
  ) THEN
    -- Drop from public
    DROP EXTENSION IF EXISTS postgis CASCADE;
    
    -- Recreate in extensions schema
    CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA extensions;
  ELSE
    -- Just ensure it exists in extensions schema
    CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA extensions;
  END IF;
END $$;

-- Grant usage on extensions schema to authenticated users
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO anon;

-- Note: spatial_ref_sys table remains in public schema as it's created by PostGIS
-- We don't enable RLS on it as it's read-only reference data
