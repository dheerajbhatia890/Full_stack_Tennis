/*
  # Add Foreign Key Indexes for Performance

  1. Performance Optimization
    - Add indexes for all foreign key columns that are missing covering indexes
    - This improves JOIN performance and foreign key constraint checking
    
  2. Tables Affected
    - clubs: admin_user_id
    - court_schedules: court_id
    - ladder_members: player_id
    - ladders: zone_id
    - matches: booking_id, ladder_id, tournament_id, winner_id
    - package_credits: package_id, player_id
    - payouts: coach_id
    - reviews: booking_id, club_id, coach_id, reviewer_id
    - tournament_participants: player_id
    - tournaments: club_id, zone_id
    - zone_enrollments: player_id
*/

-- Clubs
CREATE INDEX IF NOT EXISTS idx_clubs_admin_user_id ON public.clubs(admin_user_id);

-- Court Schedules
CREATE INDEX IF NOT EXISTS idx_court_schedules_court_id ON public.court_schedules(court_id);

-- Ladder Members
CREATE INDEX IF NOT EXISTS idx_ladder_members_player_id ON public.ladder_members(player_id);
CREATE INDEX IF NOT EXISTS idx_ladder_members_ladder_id ON public.ladder_members(ladder_id);

-- Ladders
CREATE INDEX IF NOT EXISTS idx_ladders_zone_id ON public.ladders(zone_id);

-- Matches
CREATE INDEX IF NOT EXISTS idx_matches_booking_id ON public.matches(booking_id);
CREATE INDEX IF NOT EXISTS idx_matches_ladder_id ON public.matches(ladder_id);
CREATE INDEX IF NOT EXISTS idx_matches_tournament_id ON public.matches(tournament_id);
CREATE INDEX IF NOT EXISTS idx_matches_winner_id ON public.matches(winner_id);

-- Package Credits
CREATE INDEX IF NOT EXISTS idx_package_credits_package_id ON public.package_credits(package_id);
CREATE INDEX IF NOT EXISTS idx_package_credits_player_id ON public.package_credits(player_id);

-- Payouts
CREATE INDEX IF NOT EXISTS idx_payouts_coach_id ON public.payouts(coach_id);

-- Reviews
CREATE INDEX IF NOT EXISTS idx_reviews_booking_id ON public.reviews(booking_id);
CREATE INDEX IF NOT EXISTS idx_reviews_club_id ON public.reviews(club_id);
CREATE INDEX IF NOT EXISTS idx_reviews_coach_id ON public.reviews(coach_id);
CREATE INDEX IF NOT EXISTS idx_reviews_reviewer_id ON public.reviews(reviewer_id);

-- Tournament Participants
CREATE INDEX IF NOT EXISTS idx_tournament_participants_player_id ON public.tournament_participants(player_id);
CREATE INDEX IF NOT EXISTS idx_tournament_participants_tournament_id ON public.tournament_participants(tournament_id);

-- Tournaments
CREATE INDEX IF NOT EXISTS idx_tournaments_club_id ON public.tournaments(club_id);
CREATE INDEX IF NOT EXISTS idx_tournaments_zone_id ON public.tournaments(zone_id);

-- Zone Enrollments
CREATE INDEX IF NOT EXISTS idx_zone_enrollments_player_id ON public.zone_enrollments(player_id);
CREATE INDEX IF NOT EXISTS idx_zone_enrollments_zone_id ON public.zone_enrollments(zone_id);
