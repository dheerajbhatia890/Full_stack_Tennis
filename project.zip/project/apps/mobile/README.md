# Tennis Platform Mobile App

React Native mobile application built with Expo.

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm start
```

3. Run on platform:
```bash
npm run ios
npm run android
```

## Features (To Be Implemented)

- User authentication
- Player and coach profiles
- Court booking
- Match tracking
- Tournament registration
- Real-time notifications
- Chat messaging

## Tech Stack

- React Native
- Expo
- React Navigation
- Axios for API calls
- AsyncStorage for local storage
