/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ['@tennis-platform/types'],
};

module.exports = nextConfig;
