'use client';

import Link from 'next/link';
import { Calendar, MapPin, Users, Trophy, DollarSign, ArrowLeft } from 'lucide-react';

interface Tournament {
  id: string;
  name: string;
  date: string;
  location: string;
  participants: number;
  maxParticipants: number;
  entryFee: number;
  prizePool: number;
  level: string;
  surface: string;
  status: 'Open' | 'Full' | 'Upcoming' | 'Completed';
  imageUrl: string;
}

export default function TournamentsPage() {
  const tournaments: Tournament[] = [
    {
      id: '1',
      name: 'Summer Singles Championship',
      date: '2025-12-15',
      location: 'Central Tennis Club, NY',
      participants: 24,
      maxParticipants: 32,
      entryFee: 50,
      prizePool: 1500,
      level: 'Open',
      surface: 'Hard',
      status: 'Open',
      imageUrl: 'https://images.pexels.com/photos/209977/pexels-photo-209977.jpeg?auto=compress&cs=tinysrgb&w=600',
    },
    {
      id: '2',
      name: 'Winter Doubles Classic',
      date: '2025-12-20',
      location: 'Elite Tennis Academy, NY',
      participants: 32,
      maxParticipants: 32,
      entryFee: 80,
      prizePool: 2500,
      level: 'Advanced',
      surface: 'Clay',
      status: 'Full',
      imageUrl: 'https://images.pexels.com/photos/1752757/pexels-photo-1752757.jpeg?auto=compress&cs=tinysrgb&w=600',
    },
    {
      id: '3',
      name: 'Junior Development Cup',
      date: '2025-12-10',
      location: 'Riverside Tennis Club, NY',
      participants: 18,
      maxParticipants: 24,
      entryFee: 30,
      prizePool: 800,
      level: 'Junior',
      surface: 'Hard',
      status: 'Open',
      imageUrl: 'https://images.pexels.com/photos/226587/pexels-photo-226587.jpeg?auto=compress&cs=tinysrgb&w=600',
    },
    {
      id: '4',
      name: 'Club Championship Finals',
      date: '2026-01-05',
      location: 'Downtown Tennis Center, NY',
      participants: 0,
      maxParticipants: 16,
      entryFee: 40,
      prizePool: 1000,
      level: 'Intermediate',
      surface: 'Hard',
      status: 'Upcoming',
      imageUrl: 'https://images.pexels.com/photos/6256664/pexels-photo-6256664.jpeg?auto=compress&cs=tinysrgb&w=600',
    },
  ];

  const getStatusColor = (status: Tournament['status']) => {
    switch (status) {
      case 'Open':
        return 'bg-green-100 text-green-700';
      case 'Full':
        return 'bg-red-100 text-red-700';
      case 'Upcoming':
        return 'bg-blue-100 text-blue-700';
      case 'Completed':
        return 'bg-gray-100 text-gray-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <Link href="/" className="text-2xl font-bold text-green-600">
              🎾 TennisPlatform
            </Link>
            <div className="flex gap-4">
              <Link href="/coaches" className="px-4 py-2 text-gray-700 hover:text-green-600">
                Coaches
              </Link>
              <Link href="/ladders" className="px-4 py-2 text-gray-700 hover:text-green-600">
                Ladders
              </Link>
              <Link href="/tournaments" className="px-4 py-2 text-green-600 font-medium">
                Tournaments
              </Link>
              <Link href="/courts" className="px-4 py-2 text-gray-700 hover:text-green-600">
                Courts
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Link href="/" className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 mb-6">
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Tournaments</h1>
          <p className="text-xl text-gray-600">
            Participate in tournaments and test your skills in competitive play
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {tournaments.map((tournament) => (
            <div
              key={tournament.id}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <img
                src={tournament.imageUrl}
                alt={tournament.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-xl font-bold text-gray-900">{tournament.name}</h3>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(
                      tournament.status
                    )}`}
                  >
                    {tournament.status}
                  </span>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Calendar className="w-4 h-4" />
                    <span className="text-sm">
                      {new Date(tournament.date).toLocaleDateString('en-US', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm">{tournament.location}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Users className="w-4 h-4" />
                    <span className="text-sm">
                      {tournament.participants}/{tournament.maxParticipants} participants
                    </span>
                  </div>
                </div>

                <div className="flex gap-2 mb-4">
                  <span className="px-3 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                    {tournament.level}
                  </span>
                  <span className="px-3 py-1 bg-orange-100 text-orange-700 text-xs rounded-full">
                    {tournament.surface}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <DollarSign className="w-4 h-4" />
                      <span>Entry: ${tournament.entryFee}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm font-semibold text-green-600">
                      <Trophy className="w-4 h-4" />
                      <span>Prize: ${tournament.prizePool}</span>
                    </div>
                  </div>
                  <button
                    disabled={tournament.status === 'Full' || tournament.status === 'Completed'}
                    className={`px-6 py-2 rounded-lg font-semibold transition-colors ${
                      tournament.status === 'Open'
                        ? 'bg-green-600 text-white hover:bg-green-700'
                        : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    {tournament.status === 'Full' ? 'Full' : 'Register'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-gradient-to-r from-green-600 to-green-700 rounded-lg shadow-lg p-8 text-white">
          <div className="flex items-start gap-6">
            <Trophy className="w-16 h-16 flex-shrink-0" />
            <div>
              <h2 className="text-2xl font-bold mb-2">Want to organize a tournament?</h2>
              <p className="text-green-100 mb-4">
                Create your own tournament and invite players from our community. Set your own rules,
                prizes, and format.
              </p>
              <button className="px-6 py-3 bg-white text-green-600 font-semibold rounded-lg hover:bg-green-50 transition-colors">
                Create Tournament
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
