import Link from 'next/link';
import { Search, Users, Trophy, MapPin } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="text-2xl font-bold text-green-600">🎾 TennisPlatform</div>
            <div className="flex gap-4">
              <Link
                href="/login"
                className="px-4 py-2 text-gray-700 hover:text-green-600"
              >
                Login
              </Link>
              <Link
                href="/register"
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                Sign Up
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            Find Your Perfect Tennis Match
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Connect with players, coaches, and clubs. Book courts, join tournaments, and climb the ladder.
          </p>
          <Link
            href="/register"
            className="inline-block px-8 py-4 bg-green-600 text-white text-lg font-semibold rounded-lg hover:bg-green-700"
          >
            Get Started
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <Link href="/coaches" className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <Search className="w-12 h-12 text-green-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Find Coaches</h3>
            <p className="text-gray-600">
              Discover certified coaches in your area with specialized training programs.
            </p>
          </Link>

          <Link href="/ladders" className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <Users className="w-12 h-12 text-green-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Join Ladders</h3>
            <p className="text-gray-600">
              Compete in organized ladders and track your progress against other players.
            </p>
          </Link>

          <Link href="/tournaments" className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <Trophy className="w-12 h-12 text-green-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Tournaments</h3>
            <p className="text-gray-600">
              Participate in tournaments and test your skills in competitive play.
            </p>
          </Link>

          <Link href="/courts" className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <MapPin className="w-12 h-12 text-green-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Book Courts</h3>
            <p className="text-gray-600">
              Find and reserve courts at clubs near you with real-time availability.
            </p>
          </Link>
        </div>
      </main>
    </div>
  );
}
