'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function DebugPage() {
  const [authStatus, setAuthStatus] = useState<any>(null);
  const [sessionStatus, setSessionStatus] = useState<any>(null);
  const [dbStatus, setDbStatus] = useState<any>(null);
  const [userRecord, setUserRecord] = useState<any>(null);

  useEffect(() => {
    checkStatus();
  }, []);

  const checkStatus = async () => {
    try {
      // Check auth user
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      setAuthStatus({ user, error: userError });

      // Check session
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      setSessionStatus({ session, error: sessionError });

      // Try to read from users table
      if (user) {
        const { data: userData, error: dbError } = await supabase
          .from('users')
          .select('*')
          .eq('id', user.id)
          .maybeSingle();
        
        setUserRecord({ data: userData, error: dbError });
        
        // Also check direct database connection
        const { data: testData, error: testError } = await supabase
          .from('users')
          .select('count')
          .limit(1);
        
        setDbStatus({ 
          canQuery: !testError, 
          error: testError,
          message: testError ? testError.message : 'Database accessible'
        });
      }
    } catch (err: any) {
      console.error('Debug check error:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Debug Information</h1>

        {/* Auth Status */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Auth User Status</h2>
          <pre className="bg-gray-100 p-4 rounded overflow-auto text-sm">
            {JSON.stringify(authStatus, null, 2)}
          </pre>
        </div>

        {/* Session Status */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Session Status</h2>
          <pre className="bg-gray-100 p-4 rounded overflow-auto text-sm">
            {JSON.stringify(sessionStatus, null, 2)}
          </pre>
        </div>

        {/* Database Status */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Database Access</h2>
          <pre className="bg-gray-100 p-4 rounded overflow-auto text-sm">
            {JSON.stringify(dbStatus, null, 2)}
          </pre>
        </div>

        {/* User Record */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">User Record from Database</h2>
          <pre className="bg-gray-100 p-4 rounded overflow-auto text-sm">
            {JSON.stringify(userRecord, null, 2)}
          </pre>
        </div>

        {/* Local Storage */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Local Storage Keys</h2>
          <pre className="bg-gray-100 p-4 rounded overflow-auto text-sm">
            {JSON.stringify(Object.keys(localStorage), null, 2)}
          </pre>
        </div>

        <button
          onClick={checkStatus}
          className="w-full py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700"
        >
          Refresh Debug Info
        </button>

        <button
          onClick={async () => {
            await supabase.auth.signOut();
            window.location.href = '/login';
          }}
          className="w-full py-3 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700"
        >
          Sign Out & Go to Login
        </button>
      </div>
    </div>
  );
}
