'use client';

import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import PlayerProfile from '@/components/PlayerProfile';
import CoachProfile from '@/components/CoachProfile';

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [userData, setUserData] = useState<any>(null);
  const [playerProfile, setPlayerProfile] = useState<any>(null);
  const [coachProfile, setCoachProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeView, setActiveView] = useState<'player' | 'coach'>('player');

  useEffect(() => {
    const checkUser = async () => {
      const { data: { user: authUser } } = await supabase.auth.getUser();

      if (!authUser) {
        router.push('/login');
        return;
      }

      setUser(authUser);

      // Get user data
      const { data: userRecord } = await supabase
        .from('users')
        .select('*')
        .eq('id', authUser.id)
        .maybeSingle();

      setUserData(userRecord);

      // Get player profile if user is a player
      if (userRecord?.roles?.includes('Player')) {
        const { data: playerData } = await supabase
          .from('player_profiles')
          .select('*')
          .eq('user_id', authUser.id)
          .maybeSingle();
        setPlayerProfile(playerData);
      }

      // Get coach profile if user is a coach
      if (userRecord?.roles?.includes('Coach')) {
        const { data: coachData } = await supabase
          .from('coach_profiles')
          .select('*, coach_training_locations(*)')
          .eq('user_id', authUser.id)
          .maybeSingle();
        setCoachProfile(coachData);
      }

      // Set default view based on roles
      if (userRecord?.roles?.includes('Player')) {
        setActiveView('player');
      } else if (userRecord?.roles?.includes('Coach')) {
        setActiveView('coach');
      }

      setLoading(false);
    };

    checkUser();
  }, [router]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem('registration_data');
    localStorage.removeItem('selected_roles');
    router.push('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your profile...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const hasMultipleRoles = userData?.roles?.length > 1;
  const isPlayer = userData?.roles?.includes('Player');
  const isCoach = userData?.roles?.includes('Coach');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation Bar */}
      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="text-2xl font-bold text-green-600">Tennis Platform</div>
            
            <div className="flex items-center gap-4">
              {hasMultipleRoles && (
                <div className="flex gap-2">
                  {isPlayer && (
                    <button
                      onClick={() => setActiveView('player')}
                      className={`px-4 py-2 rounded-lg font-medium transition ${
                        activeView === 'player'
                          ? 'bg-green-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      Player View
                    </button>
                  )}
                  {isCoach && (
                    <button
                      onClick={() => setActiveView('coach')}
                      className={`px-4 py-2 rounded-lg font-medium transition ${
                        activeView === 'coach'
                          ? 'bg-green-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      Coach Corner
                    </button>
                  )}
                </div>
              )}
              
              <span className="text-gray-700">{userData?.first_name} {userData?.last_name}</span>
              
              <button
                onClick={handleLogout}
                className="px-4 py-2 text-gray-700 hover:text-red-600 font-medium transition"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main>
        {activeView === 'player' && isPlayer && (
          <PlayerProfile 
            user={user} 
            userData={userData} 
            playerProfile={playerProfile}
          />
        )}
        
        {activeView === 'coach' && isCoach && (
          <CoachProfile 
            user={user} 
            userData={userData} 
            coachProfile={coachProfile}
          />
        )}

        {!isPlayer && !isCoach && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900">Welcome!</h2>
              <p className="mt-2 text-gray-600">Please complete your profile to get started.</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
