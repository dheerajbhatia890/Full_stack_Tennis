'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type Role = 'Player' | 'Coach' | 'Club Admin';

export default function RoleSelectionPage() {
  const [selectedRoles, setSelectedRoles] = useState<Role[]>([]);
  const [error, setError] = useState('');
  const router = useRouter();

  const roles: { value: Role; label: string; description: string }[] = [
    { value: 'Player', label: 'Player', description: 'Find courts, book matches, join tournaments' },
    { value: 'Coach', label: 'Coach', description: 'Offer lessons, manage students, grow your business' },
    { value: 'Club Admin', label: 'Club Admin', description: 'Manage facilities, courts, and bookings' },
  ];

  const toggleRole = (role: Role) => {
    setSelectedRoles(prev =>
      prev.includes(role)
        ? prev.filter(r => r !== role)
        : [...prev, role]
    );
    setError('');
  };

  const handleContinue = () => {
    if (selectedRoles.length === 0) {
      setError('Please select at least one role');
      return;
    }

    localStorage.setItem('selected_roles', JSON.stringify(selectedRoles));

    if (selectedRoles.includes('Player')) {
      router.push('/onboarding/player');
    } else if (selectedRoles.includes('Coach')) {
      router.push('/onboarding/coach');
    } else {
      router.push('/onboarding/club-admin');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-green-50 flex items-center justify-center px-4 py-12">
      <div className="max-w-3xl w-full">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold text-gray-900 mb-3">Tell us your role(s)</h1>
          <p className="text-lg text-gray-600">You can select multiple roles</p>
        </div>

        <div className="space-y-4 mb-8">
          {roles.map((role) => (
            <button
              key={role.value}
              onClick={() => toggleRole(role.value)}
              className={`w-full p-6 rounded-2xl border-2 transition-all transform hover:scale-[1.02] active:scale-[0.98] text-left ${
                selectedRoles.includes(role.value)
                  ? 'border-green-600 bg-green-50 shadow-lg'
                  : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-md'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-1">
                    {role.label}
                  </h3>
                  <p className="text-gray-600">{role.description}</p>
                </div>
                <div className={`flex-shrink-0 ml-4 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                  selectedRoles.includes(role.value)
                    ? 'border-green-600 bg-green-600'
                    : 'border-gray-300'
                }`}>
                  {selectedRoles.includes(role.value) && (
                    <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl text-center mb-6">
            {error}
          </div>
        )}

        <button
          onClick={handleContinue}
          className="w-full py-4 bg-green-600 text-white text-lg font-semibold rounded-xl hover:bg-green-700 transition transform hover:scale-[1.02] active:scale-[0.98] shadow-lg"
        >
          Continue
        </button>
      </div>
    </div>
  );
}
