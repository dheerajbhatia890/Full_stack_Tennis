'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Camera, Plus, X, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';

type OperatingHours = {
  day: string;
  open: string;
  close: string;
  isClosed: boolean;
};

type Court = {
  name: string;
  surface: string;
  isIndoor: boolean;
  hasLights: boolean;
  hourlyRate: string;
};

export default function ClubAdminSetupPage() {
  const [clubName, setClubName] = useState('');
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [website, setWebsite] = useState('');
  const [profileImage, setProfileImage] = useState<string>('');
  const [courts, setCourts] = useState<Court[]>([]);
  const [showCourtForm, setShowCourtForm] = useState(false);
  const [operatingHours, setOperatingHours] = useState<OperatingHours[]>([
    { day: 'Monday', open: '08:00', close: '20:00', isClosed: false },
    { day: 'Tuesday', open: '08:00', close: '20:00', isClosed: false },
    { day: 'Wednesday', open: '08:00', close: '20:00', isClosed: false },
    { day: 'Thursday', open: '08:00', close: '20:00', isClosed: false },
    { day: 'Friday', open: '08:00', close: '20:00', isClosed: false },
    { day: 'Saturday', open: '09:00', close: '18:00', isClosed: false },
    { day: 'Sunday', open: '09:00', close: '18:00', isClosed: false },
  ]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const surfaceTypes = ['Hard', 'Clay', 'Grass', 'Carpet'];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const updateOperatingHours = (index: number, field: keyof OperatingHours, value: string | boolean) => {
    setOperatingHours(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const addCourt = (court: Court) => {
    setCourts(prev => [...prev, court]);
    setShowCourtForm(false);
  };

  const removeCourt = (index: number) => {
    setCourts(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!clubName || !address || courts.length === 0) {
      setError('Please fill in club name, address, and add at least one court');
      return;
    }

    setLoading(true);

    try {
      const { data: { user: authUser } } = await supabase.auth.getUser();

      if (!authUser) {
        setError('User session not found. Please log in again.');
        setLoading(false);
        router.push('/login');
        return;
      }

      const operatingHoursJson = operatingHours.reduce((acc, day) => {
        acc[day.day.toLowerCase()] = day.isClosed
          ? { closed: true }
          : { open: day.open, close: day.close };
        return acc;
      }, {} as any);

      const { data: clubData, error: clubError } = await supabase
        .from('clubs')
        .insert({
          name: clubName,
          description: description || null,
          address: address,
          phone: phone || null,
          email: email || null,
          website: website || null,
          admin_user_id: authUser.id,
          operating_hours: operatingHoursJson,
          profile_image_url: profileImage || null
        })
        .select()
        .single();

      if (clubError) {
        console.error('Error creating club:', clubError);
        setError('Failed to create club. Please try again.');
        setLoading(false);
        return;
      }

      if (clubData && courts.length > 0) {
        const courtInserts = courts.map(court => ({
          club_id: clubData.id,
          name: court.name,
          surface: court.surface,
          is_indoor: court.isIndoor,
          has_lights: court.hasLights,
          hourly_rate: parseFloat(court.hourlyRate) || null,
          is_active: true
        }));

        const { error: courtsError } = await supabase
          .from('courts')
          .insert(courtInserts);

        if (courtsError) {
          console.error('Error creating courts:', courtsError);
        }
      }

      await supabase
        .from('users')
        .update({ onboarding_completed: true })
        .eq('id', authUser.id);

      router.push('/dashboard');
    } catch (err: any) {
      console.error('Error:', err);
      setError(err.message || 'Failed to save club. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-green-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-3">Club Setup</h1>
          <p className="text-lg text-gray-600">Set up your tennis club</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-xl text-sm">
                {error}
              </div>
            )}

            <div className="flex justify-center">
              <div className="relative">
                <div className="w-32 h-32 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden border-4 border-gray-200">
                  {profileImage ? (
                    <img src={profileImage} alt="Club" className="w-full h-full object-cover" />
                  ) : (
                    <Camera className="w-12 h-12 text-gray-400" />
                  )}
                </div>
                <label className="absolute bottom-0 right-0 bg-green-600 rounded-full p-2 cursor-pointer hover:bg-green-700 transition">
                  <Camera className="w-5 h-5 text-white" />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div>
              <label htmlFor="clubName" className="block text-sm font-medium text-gray-700 mb-2">
                Club Name <span className="text-red-500">*</span>
              </label>
              <input
                id="clubName"
                type="text"
                value={clubName}
                onChange={(e) => setClubName(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Your tennis club name"
              />
            </div>

            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                placeholder="Describe your club..."
              />
            </div>

            <div>
              <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-2">
                Club Address <span className="text-red-500">*</span>
              </label>
              <input
                id="address"
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Full address"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                  Phone
                </label>
                <input
                  id="phone"
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="(555) 123-4567"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="club@example.com"
                />
              </div>

              <div>
                <label htmlFor="website" className="block text-sm font-medium text-gray-700 mb-2">
                  Website
                </label>
                <input
                  id="website"
                  type="url"
                  value={website}
                  onChange={(e) => setWebsite(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="https://..."
                />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 mb-3">
                <Clock className="w-5 h-5 text-gray-600" />
                <label className="block text-sm font-medium text-gray-700">
                  Operating Hours
                </label>
              </div>
              <div className="space-y-3 bg-gray-50 p-4 rounded-xl">
                {operatingHours.map((day, index) => (
                  <div key={day.day} className="flex items-center gap-4">
                    <div className="w-24 font-medium text-gray-700">{day.day}</div>
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={day.isClosed}
                        onChange={(e) => updateOperatingHours(index, 'isClosed', e.target.checked)}
                        className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                      />
                      <span className="text-sm text-gray-600">Closed</span>
                    </label>
                    {!day.isClosed && (
                      <>
                        <input
                          type="time"
                          value={day.open}
                          onChange={(e) => updateOperatingHours(index, 'open', e.target.value)}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                        <span className="text-gray-500">to</span>
                        <input
                          type="time"
                          value={day.close}
                          onChange={(e) => updateOperatingHours(index, 'close', e.target.value)}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="block text-sm font-medium text-gray-700">
                  Courts <span className="text-red-500">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => setShowCourtForm(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-xl hover:bg-green-700 transition text-sm font-medium"
                >
                  <Plus className="w-4 h-4" />
                  Add Court
                </button>
              </div>

              {courts.length > 0 && (
                <div className="space-y-3 mb-4">
                  {courts.map((court, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-xl border border-gray-200">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{court.name}</h4>
                          <div className="flex flex-wrap gap-2 mt-2">
                            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                              {court.surface}
                            </span>
                            {court.isIndoor && (
                              <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">
                                Indoor
                              </span>
                            )}
                            {court.hasLights && (
                              <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full">
                                Lights
                              </span>
                            )}
                            {court.hourlyRate && (
                              <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                                ${court.hourlyRate}/hr
                              </span>
                            )}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeCourt(index)}
                          className="text-red-500 hover:text-red-700 transition"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {showCourtForm && (
                <CourtForm
                  surfaceTypes={surfaceTypes}
                  onSave={addCourt}
                  onCancel={() => setShowCourtForm(false)}
                />
              )}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-green-600 text-white text-lg font-semibold rounded-xl hover:bg-green-700 disabled:opacity-50 transition transform hover:scale-[1.02] active:scale-[0.98] shadow-lg"
            >
              {loading ? 'Saving...' : 'Complete Setup'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

function CourtForm({ surfaceTypes, onSave, onCancel }: {
  surfaceTypes: string[];
  onSave: (court: Court) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState('');
  const [surface, setSurface] = useState('');
  const [isIndoor, setIsIndoor] = useState(false);
  const [hasLights, setHasLights] = useState(false);
  const [hourlyRate, setHourlyRate] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name || !surface) {
      setError('Please fill in court name and surface type');
      return;
    }

    onSave({
      name,
      surface,
      isIndoor,
      hasLights,
      hourlyRate
    });
  };

  return (
    <div className="bg-slate-50 p-6 rounded-xl border-2 border-green-200 mt-3">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Add Court</h3>

      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-2 rounded-lg text-sm">
            {error}
          </div>
        )}

        <div>
          <label htmlFor="courtName" className="block text-sm font-medium text-gray-700 mb-1">
            Court Name <span className="text-red-500">*</span>
          </label>
          <input
            id="courtName"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            placeholder="e.g., Court 1, Center Court"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Surface Type <span className="text-red-500">*</span>
          </label>
          <div className="grid grid-cols-2 gap-2">
            {surfaceTypes.map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setSurface(type)}
                className={`py-2 px-3 rounded-lg text-sm font-medium transition ${
                  surface === type
                    ? 'bg-green-600 text-white shadow-md'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        <div className="flex gap-4">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={isIndoor}
              onChange={(e) => setIsIndoor(e.target.checked)}
              className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
            />
            <span className="text-sm font-medium text-gray-700">Indoor</span>
          </label>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={hasLights}
              onChange={(e) => setHasLights(e.target.checked)}
              className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
            />
            <span className="text-sm font-medium text-gray-700">Has Lights</span>
          </label>
        </div>

        <div>
          <label htmlFor="hourlyRate" className="block text-sm font-medium text-gray-700 mb-1">
            Hourly Rate ($)
          </label>
          <input
            id="hourlyRate"
            type="number"
            value={hourlyRate}
            onChange={(e) => setHourlyRate(e.target.value)}
            min="0"
            step="0.01"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            placeholder="e.g., 25.00"
          />
        </div>

        <div className="flex gap-3 pt-2">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 py-2 px-4 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition font-medium"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex-1 py-2 px-4 bg-green-600 text-white rounded-lg hover:bg-green-700 transition font-medium"
          >
            Add Court
          </button>
        </div>
      </form>
    </div>
  );
}
