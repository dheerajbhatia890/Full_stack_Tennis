'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Camera } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export default function PlayerSetupPage() {
  const [profileImage, setProfileImage] = useState<string>('');
  const [ageGroup, setAgeGroup] = useState('');
  const [yearsPlaying, setYearsPlaying] = useState('');
  const [skillLevel, setSkillLevel] = useState('');
  const [gameDescription, setGameDescription] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const ageGroups = ['Under 8', 'Under 10', 'Under 12', 'Under 14', 'Under 16', 'Under 18', '18–39', '40–59', '60+'];
  const yearsPlayingOptions = ['0-5 Years', '6-10 Years', '11-20 Years', '20+ Years'];
  const skillLevels = ['Beginner', 'Advanced Beginner', 'Intermediate', 'Advanced', 'Professional'];

  const usStates = [
    'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware',
    'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky',
    'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi',
    'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico',
    'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania',
    'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont',
    'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!ageGroup || !yearsPlaying || !skillLevel || !city || !state) {
      setError('Please fill in all required fields');
      return;
    }

    setLoading(true);

    try {
      // Check session first
      const { data: { session } } = await supabase.auth.getSession();
      console.log('Current session:', session ? 'Active' : 'No session');
      
      const { data: { user: authUser } } = await supabase.auth.getUser();

      if (!authUser || !session) {
        console.error('Session lost - User:', authUser?.id, 'Session:', session?.access_token);
        setError('Your session has expired. Please log in again.');
        setLoading(false);
        // Store current progress before redirecting
        localStorage.setItem('onboarding_progress', JSON.stringify({
          step: 'player',
          data: { ageGroup, yearsPlaying, skillLevel, gameDescription, city, state, profileImage }
        }));
        router.push('/login');
        return;
      }

      const registrationData = JSON.parse(localStorage.getItem('registration_data') || '{}');
      const selectedRoles = JSON.parse(localStorage.getItem('selected_roles') || '[]');
      const userId = authUser.id;

      console.log('Creating player profile for user:', userId);
      console.log('Selected roles:', selectedRoles);

      const { data: userData, error: updateError } = await supabase
        .from('users')
        .update({
          roles: selectedRoles,
          profile_image_url: profileImage || null
        })
        .eq('id', userId)
        .select()
        .single();

      if (updateError) {
        console.error('Error updating user:', updateError);
        setError('Failed to update user roles. Please try again.');
        setLoading(false);
        return;
      }

      const { error: playerError } = await supabase
        .from('player_profiles')
        .insert({
          user_id: userId,
          first_name: registrationData.firstName,
          last_name: registrationData.lastName,
          age_group: ageGroup,
          skill_level: skillLevel,
          bio: gameDescription || null,
          city: city,
          state: state,
          profile_image_url: profileImage || null
        });

      if (playerError) {
        console.error('Error creating player profile:', playerError);
        setError('Failed to create player profile. Please try again.');
        setLoading(false);
        return;
      }

      console.log('Player profile created successfully');

      // Check which profiles still need to be created
      const checks = await Promise.all([
        selectedRoles.includes('Coach')
          ? supabase.from('coach_profiles').select('id').eq('user_id', userId).maybeSingle()
          : { data: { id: 'skip' } },
        selectedRoles.includes('Club Admin')
          ? supabase.from('clubs').select('id').eq('admin_user_id', userId).maybeSingle()
          : { data: { id: 'skip' } }
      ]);

      const [coachProfile, clubProfile] = checks;

      console.log('Coach profile exists:', coachProfile.data ? 'Yes' : 'No');
      console.log('Club profile exists:', clubProfile.data ? 'Yes' : 'No');

      if (selectedRoles.includes('Coach') && !coachProfile.data) {
        console.log('Navigating to coach setup...');
        router.push('/onboarding/coach');
      } else if (selectedRoles.includes('Club Admin') && !clubProfile.data) {
        console.log('Navigating to club admin setup...');
        router.push('/onboarding/club-admin');
      } else {
        console.log('All profiles complete, marking onboarding as done...');
        await supabase
          .from('users')
          .update({ onboarding_completed: true })
          .eq('id', userId);

        router.push('/dashboard');
      }
    } catch (err: any) {
      console.error('Error:', err);
      setError(err.message || 'Failed to save profile. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-green-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-3">Player Setup</h1>
          <p className="text-lg text-gray-600">Tell us about your game</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-xl text-sm">
                {error}
              </div>
            )}

            <div className="flex justify-center">
              <div className="relative">
                <div className="w-32 h-32 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden border-4 border-gray-200">
                  {profileImage ? (
                    <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <Camera className="w-12 h-12 text-gray-400" />
                  )}
                </div>
                <label className="absolute bottom-0 right-0 bg-green-600 rounded-full p-2 cursor-pointer hover:bg-green-700 transition">
                  <Camera className="w-5 h-5 text-white" />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Age Group <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-3 gap-3">
                {ageGroups.map((group) => (
                  <button
                    key={group}
                    type="button"
                    onClick={() => setAgeGroup(group)}
                    className={`py-3 px-4 rounded-xl font-medium transition ${
                      ageGroup === group
                        ? 'bg-green-600 text-white shadow-md'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {group}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Years Playing <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                {yearsPlayingOptions.map((option) => (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setYearsPlaying(option)}
                    className={`py-3 px-4 rounded-xl font-medium transition ${
                      yearsPlaying === option
                        ? 'bg-green-600 text-white shadow-md'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Skill Level <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                {skillLevels.map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setSkillLevel(level)}
                    className={`py-3 px-4 rounded-xl font-medium transition ${
                      skillLevel === level
                        ? 'bg-green-600 text-white shadow-md'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="gameDescription" className="block text-sm font-medium text-gray-700 mb-2">
                Tell us about your game
              </label>
              <textarea
                id="gameDescription"
                value={gameDescription}
                onChange={(e) => setGameDescription(e.target.value)}
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                placeholder="Describe your playing style, strengths, goals..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-2">
                  City <span className="text-red-500">*</span>
                </label>
                <input
                  id="city"
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Your city"
                  required
                />
              </div>

              <div>
                <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-2">
                  State <span className="text-red-500">*</span>
                </label>
                <select
                  id="state"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
                  required
                >
                  <option value="">Select a state</option>
                  {usStates.map((stateName) => (
                    <option key={stateName} value={stateName}>
                      {stateName}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-green-600 text-white text-lg font-semibold rounded-xl hover:bg-green-700 disabled:opacity-50 transition transform hover:scale-[1.02] active:scale-[0.98] shadow-lg"
            >
              {loading ? 'Saving...' : 'Continue'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
