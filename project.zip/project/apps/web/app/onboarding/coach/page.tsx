'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Camera, Plus, X, MapPin } from 'lucide-react';
import TrainingLocationForm from '@/components/TrainingLocationForm';
import { supabase } from '@/lib/supabase';

type TrainingLocation = {
  locationName: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  zipCode: string;
  travelRadius: string;
  googleMapsLink: string;
  isPreferred: boolean;
};

export default function CoachSetupPage() {
  const [profileImage, setProfileImage] = useState<string>('');
  const [yearsExperience, setYearsExperience] = useState('');
  const [coachType, setCoachType] = useState('');
  const [playerTypes, setPlayerTypes] = useState<string[]>([]);
  const [certificationProof, setCertificationProof] = useState<string>('');
  const [bio, setBio] = useState('');
  const [coachingExperience, setCoachingExperience] = useState('');
  const [teachingStyle, setTeachingStyle] = useState('');
  const [achievements, setAchievements] = useState('');
  const [featuredIn, setFeaturedIn] = useState('');
  const [trainingLocations, setTrainingLocations] = useState<TrainingLocation[]>([]);
  const [showLocationForm, setShowLocationForm] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const coachTypes = [
    'Full-Time Professional Coach (> 30 hours)',
    'Part-Time Professional Coach (< 30 hours)',
  ];

  const playerTypeOptions = [
    'Kids',
    'Juniors',
    'High-performance juniors',
    'Adults',
    'Seniors',
    'Middle school teams',
    'High school teams',
    'Beginner players',
    'Intermediate players',
    'Advanced players',
  ];


  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCertificationUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCertificationProof(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const togglePlayerType = (type: string) => {
    setPlayerTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };


  const addTrainingLocation = (location: TrainingLocation) => {
    setTrainingLocations(prev => [...prev, location]);
    setShowLocationForm(false);
    setError('');
  };

  const removeTrainingLocation = (index: number) => {
    setTrainingLocations(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!yearsExperience || !coachType || playerTypes.length === 0) {
      setError('Please fill in all required fields');
      return;
    }

    setLoading(true);

    try {
      const { data: { user: authUser } } = await supabase.auth.getUser();

      if (!authUser) {
        setError('User session not found. Please log in again.');
        setLoading(false);
        router.push('/login');
        return;
      }

      const registrationData = JSON.parse(localStorage.getItem('registration_data') || '{}');
      const selectedRoles = JSON.parse(localStorage.getItem('selected_roles') || '[]');
      const userId = authUser.id;

      const { error: coachError } = await supabase
        .from('coach_profiles')
        .insert({
          user_id: userId,
          first_name: registrationData.firstName,
          last_name: registrationData.lastName,
          years_experience: parseFloat(yearsExperience),
          coach_type: coachType,
          player_types_coached: playerTypes,
          certification_proof_url: certificationProof || null,
          bio: bio || null,
          coaching_experience_description: coachingExperience || null,
          teaching_style_description: teachingStyle || null,
          achievements: achievements || null,
          featured_in: featuredIn || null,
          profile_image_url: profileImage || null,
          base_rate: 0
        });

      if (coachError) {
        console.error('Error creating coach profile:', coachError);
        setError('Failed to create coach profile. Please try again.');
        setLoading(false);
        return;
      }

      const { data: coachProfile } = await supabase
        .from('coach_profiles')
        .select('id')
        .eq('user_id', userId)
        .maybeSingle();

      if (coachProfile && trainingLocations.length > 0) {
        const locationInserts = trainingLocations.map(loc => ({
          coach_id: coachProfile.id,
          location_name: loc.locationName,
          address_line1: loc.addressLine1,
          address_line2: loc.addressLine2 || null,
          city: loc.city,
          state: loc.state,
          zip_code: loc.zipCode,
          travel_radius: parseFloat(loc.travelRadius) || null,
          google_maps_link: loc.googleMapsLink || null,
          is_preferred: loc.isPreferred
        }));

        const { error: locationError } = await supabase
          .from('coach_training_locations')
          .insert(locationInserts);

        if (locationError) {
          console.error('Error creating training locations:', locationError);
        }
      }

      // Check if club admin profile still needs to be created
      if (selectedRoles.includes('Club Admin')) {
        const { data: clubProfile } = await supabase
          .from('clubs')
          .select('id')
          .eq('admin_user_id', userId)
          .maybeSingle();

        if (!clubProfile) {
          router.push('/onboarding/club-admin');
          return;
        }
      }

      // All profiles complete
      await supabase
        .from('users')
        .update({ onboarding_completed: true })
        .eq('id', userId);

      router.push('/dashboard');
    } catch (err: any) {
      console.error('Error:', err);
      setError(err.message || 'Failed to save profile. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-green-50 py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-3">Coach Setup</h1>
          <p className="text-lg text-gray-600">Share your coaching expertise</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-xl text-sm">
                {error}
              </div>
            )}

            <div className="flex justify-center">
              <div className="relative">
                <div className="w-32 h-32 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden border-4 border-gray-200">
                  {profileImage ? (
                    <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <Camera className="w-12 h-12 text-gray-400" />
                  )}
                </div>
                <label className="absolute bottom-0 right-0 bg-green-600 rounded-full p-2 cursor-pointer hover:bg-green-700 transition">
                  <Camera className="w-5 h-5 text-white" />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div>
              <label htmlFor="yearsExperience" className="block text-sm font-medium text-gray-700 mb-2">
                Years Teaching Experience <span className="text-red-500">*</span>
              </label>
              <input
                id="yearsExperience"
                type="number"
                value={yearsExperience}
                onChange={(e) => setYearsExperience(e.target.value)}
                required
                min="0"
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Number of years"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Coach Type / Workload <span className="text-red-500">*</span>
              </label>
              <div className="space-y-3">
                {coachTypes.map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setCoachType(type)}
                    className={`w-full py-3 px-4 rounded-xl font-medium transition text-left ${
                      coachType === type
                        ? 'bg-green-600 text-white shadow-md'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Types of Players You Coach <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                {playerTypeOptions.map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => togglePlayerType(type)}
                    className={`py-2 px-3 rounded-xl text-sm font-medium transition ${
                      playerTypes.includes(type)
                        ? 'bg-green-600 text-white shadow-md'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>


            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Upload Proof of Certification (Optional)
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-green-500 transition">
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={handleCertificationUpload}
                  className="hidden"
                  id="certification-upload"
                />
                <label htmlFor="certification-upload" className="cursor-pointer">
                  {certificationProof ? (
                    <div className="text-green-600 font-medium">File uploaded</div>
                  ) : (
                    <>
                      <div className="text-gray-400 mb-2">
                        <Camera className="w-8 h-8 mx-auto" />
                      </div>
                      <div className="text-sm text-gray-600">Click to upload certification</div>
                    </>
                  )}
                </label>
              </div>
            </div>

            <div>
              <label htmlFor="bio" className="block text-sm font-medium text-gray-700 mb-2">
                Short Bio / About Me
              </label>
              <textarea
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                placeholder="Tell students about yourself..."
              />
            </div>

            <div>
              <label htmlFor="coachingExperience" className="block text-sm font-medium text-gray-700 mb-2">
                Coaching Experience Description
              </label>
              <textarea
                id="coachingExperience"
                value={coachingExperience}
                onChange={(e) => setCoachingExperience(e.target.value)}
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                placeholder="Describe your coaching background, notable students, tournament results..."
              />
            </div>

            <div>
              <label htmlFor="teachingStyle" className="block text-sm font-medium text-gray-700 mb-2">
                Teaching Style Description
              </label>
              <textarea
                id="teachingStyle"
                value={teachingStyle}
                onChange={(e) => setTeachingStyle(e.target.value)}
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                placeholder="Describe your approach to teaching tennis..."
              />
            </div>

            <div>
              <label htmlFor="achievements" className="block text-sm font-medium text-gray-700 mb-2">
                Achievements (Optional)
              </label>
              <textarea
                id="achievements"
                value={achievements}
                onChange={(e) => setAchievements(e.target.value)}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                placeholder="Awards, certifications, achievements..."
              />
            </div>

            <div>
              <label htmlFor="featuredIn" className="block text-sm font-medium text-gray-700 mb-2">
                Featured In (Optional)
              </label>
              <textarea
                id="featuredIn"
                value={featuredIn}
                onChange={(e) => setFeaturedIn(e.target.value)}
                rows={2}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                placeholder="Media appearances, programs, publications..."
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="block text-sm font-medium text-gray-700">
                  Training Locations
                </label>
                <button
                  type="button"
                  onClick={() => setShowLocationForm(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-xl hover:bg-green-700 transition text-sm font-medium"
                >
                  <Plus className="w-4 h-4" />
                  Add Location
                </button>
              </div>

              {trainingLocations.length > 0 && (
                <div className="space-y-3 mb-4">
                  {trainingLocations.map((location, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-xl border border-gray-200">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <MapPin className="w-4 h-4 text-gray-500" />
                            <h4 className="font-semibold text-gray-900">{location.locationName}</h4>
                            {location.isPreferred && (
                              <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                                Preferred
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-gray-600">
                            {location.addressLine1}
                            {location.addressLine2 && `, ${location.addressLine2}`}
                          </p>
                          <p className="text-sm text-gray-600">
                            {location.city}, {location.state} {location.zipCode}
                          </p>
                          {location.travelRadius && (
                            <p className="text-sm text-gray-500 mt-1">
                              Travel radius: {location.travelRadius} miles
                            </p>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => removeTrainingLocation(index)}
                          className="text-red-500 hover:text-red-700 transition"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {showLocationForm && (
                <TrainingLocationForm
                  onSave={addTrainingLocation}
                  onCancel={() => setShowLocationForm(false)}
                />
              )}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-green-600 text-white text-lg font-semibold rounded-xl hover:bg-green-700 disabled:opacity-50 transition transform hover:scale-[1.02] active:scale-[0.98] shadow-lg"
            >
              {loading ? 'Saving...' : 'Continue'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
