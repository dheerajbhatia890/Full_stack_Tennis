'use client';

import Link from 'next/link';
import { ArrowLeft, TrendingUp, TrendingDown, Minus, Trophy, Users } from 'lucide-react';

interface Player {
  rank: number;
  previousRank: number;
  name: string;
  points: number;
  wins: number;
  losses: number;
  winRate: number;
}

export default function LaddersPage() {
  const players: Player[] = [
    { rank: 1, previousRank: 1, name: 'Alex Thompson', points: 2450, wins: 28, losses: 4, winRate: 87.5 },
    { rank: 2, previousRank: 3, name: 'Maria Garcia', points: 2380, wins: 26, losses: 5, winRate: 83.9 },
    { rank: 3, previousRank: 2, name: 'James Wilson', points: 2340, wins: 25, losses: 6, winRate: 80.6 },
    { rank: 4, previousRank: 4, name: 'Sarah Kim', points: 2290, wins: 24, losses: 7, winRate: 77.4 },
    { rank: 5, previousRank: 7, name: 'David Martinez', points: 2250, wins: 23, losses: 7, winRate: 76.7 },
    { rank: 6, previousRank: 5, name: 'Emily Chen', points: 2210, wins: 22, losses: 8, winRate: 73.3 },
    { rank: 7, previousRank: 6, name: 'Michael Brown', points: 2180, wins: 21, losses: 9, winRate: 70.0 },
    { rank: 8, previousRank: 9, name: 'Lisa Anderson', points: 2150, wins: 20, losses: 9, winRate: 69.0 },
    { rank: 9, previousRank: 8, name: 'Robert Taylor', points: 2120, wins: 19, losses: 10, winRate: 65.5 },
    { rank: 10, previousRank: 10, name: 'Jessica Lee', points: 2090, wins: 18, losses: 11, winRate: 62.1 },
  ];

  const getRankChange = (current: number, previous: number) => {
    if (current < previous) return 'up';
    if (current > previous) return 'down';
    return 'same';
  };

  const getRankIcon = (change: string) => {
    if (change === 'up') return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (change === 'down') return <TrendingDown className="w-4 h-4 text-red-600" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <Link href="/" className="text-2xl font-bold text-green-600">
              🎾 TennisPlatform
            </Link>
            <div className="flex gap-4">
              <Link href="/coaches" className="px-4 py-2 text-gray-700 hover:text-green-600">
                Coaches
              </Link>
              <Link href="/ladders" className="px-4 py-2 text-green-600 font-medium">
                Ladders
              </Link>
              <Link href="/tournaments" className="px-4 py-2 text-gray-700 hover:text-green-600">
                Tournaments
              </Link>
              <Link href="/courts" className="px-4 py-2 text-gray-700 hover:text-green-600">
                Courts
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Link href="/" className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 mb-6">
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Club Ladder Rankings</h1>
          <p className="text-xl text-gray-600">Compete in organized ladders and track your progress against other players</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <Users className="w-10 h-10 text-green-600 mb-3" />
            <div className="text-3xl font-bold text-gray-900 mb-1">{players.length}</div>
            <div className="text-sm text-gray-600">Active Players</div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <Trophy className="w-10 h-10 text-yellow-500 mb-3" />
            <div className="text-3xl font-bold text-gray-900 mb-1">324</div>
            <div className="text-sm text-gray-600">Total Matches</div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <TrendingUp className="w-10 h-10 text-blue-600 mb-3" />
            <div className="text-3xl font-bold text-gray-900 mb-1">42</div>
            <div className="text-sm text-gray-600">This Week</div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Rank
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Player
                  </th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Points
                  </th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Wins
                  </th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Losses
                  </th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Win Rate
                  </th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Change
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {players.map((player) => {
                  const rankChange = getRankChange(player.rank, player.previousRank);
                  return (
                    <tr key={player.rank} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl font-bold text-gray-900">#{player.rank}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-semibold text-gray-900">{player.name}</div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="font-semibold text-green-600">{player.points}</span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="text-gray-900">{player.wins}</span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="text-gray-900">{player.losses}</span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="font-medium text-gray-900">{player.winRate}%</span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex justify-center">
                          {getRankIcon(rankChange)}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-8 bg-gradient-to-r from-green-600 to-green-700 rounded-lg shadow-lg p-8 text-white">
          <h2 className="text-2xl font-bold mb-2">Ready to Compete?</h2>
          <p className="text-green-100 mb-4">
            Challenge players in your skill level and climb the ladder rankings. Every match counts!
          </p>
          <button className="px-6 py-3 bg-white text-green-600 font-semibold rounded-lg hover:bg-green-50 transition-colors">
            Challenge a Player
          </button>
        </div>
      </main>
    </div>
  );
}
