'use client';

import { useState } from 'react';
import { Trophy, Target, Calendar, Award, Settings, Camera, MessageCircle, Users, TrendingUp } from 'lucide-react';

interface PlayerProfileProps {
  user: any;
  userData: any;
  playerProfile: any;
}

type TabType = 'overview' | 'match-history' | 'rankings' | 'achievements' | 'media' | 'settings';

export default function PlayerProfile({ user, userData, playerProfile }: PlayerProfileProps) {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  
  // Mock data - replace with real data from your database
  const stats = {
    matchesPlayed: 45,
    wins: 32,
    losses: 13,
    ladderPosition: 5,
    tournamentResults: '3 Wins, 2 Finals'
  };

  const ustaRatingOptions = ['1.0', '1.5', '2.0', '2.5', '3.0', '3.5', '4.0', '4.5', '5.0', '5.5'];

  const activities = [
    { type: 'match', description: 'Won against John Doe', date: '2 days ago' },
    { type: 'tournament', description: 'Participated in Spring Open', date: '1 week ago' },
    { type: 'achievement', description: 'Unlocked "Ace Machine" badge', date: '2 weeks ago' }
  ];

  const matchHistory = [
    { opponent: 'John Doe', score: '6-4, 6-3', event: 'Club Ladder', date: '2025-11-28', result: 'W' },
    { opponent: 'Jane Smith', score: '4-6, 6-7', event: 'Tournament', date: '2025-11-20', result: 'L' }
  ];

  const badges = [
    { name: 'Verified', icon: '✓', color: 'bg-blue-500' },
    { name: 'Ace Machine', icon: '🎯', color: 'bg-yellow-500' },
    { name: 'Top 10 in Zone', icon: '🏆', color: 'bg-purple-500' },
    { name: '100 Matches', icon: '💯', color: 'bg-green-500' }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            {/* Quick Stats */}
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Matches Played</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.matchesPlayed}</p>
                  </div>
                  <Target className="w-8 h-8 text-green-600" />
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Win / Loss</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.wins} / {stats.losses}</p>
                  </div>
                  <Trophy className="w-8 h-8 text-yellow-600" />
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Ladder Position</p>
                    <p className="text-2xl font-bold text-gray-900">#{stats.ladderPosition}</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-blue-600" />
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Tournament Results</p>
                    <p className="text-lg font-bold text-gray-900">{stats.tournamentResults}</p>
                  </div>
                  <Award className="w-8 h-8 text-purple-600" />
                </div>
              </div>
            </div>

            {/* Player Bio */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Player Bio</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600 mb-2">About Me</p>
                  <p className="text-gray-900">{playerProfile?.bio || 'No bio added yet'}</p>
                </div>
                <div className="space-y-3">
                  <div>
                    <span className="text-sm text-gray-600">Preferred Format:</span>
                    <span className="ml-2 text-gray-900 font-medium">Singles, Doubles</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">Dominant Hand:</span>
                    <span className="ml-2 text-gray-900 font-medium">Right</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">Favorite Surface:</span>
                    <span className="ml-2 text-gray-900 font-medium">Hard Court</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Activity Feed */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Activity Feed</h3>
              <div className="space-y-4">
                {activities.map((activity, index) => (
                  <div key={index} className="flex items-start gap-3 pb-4 border-b last:border-0">
                    <div className="w-2 h-2 rounded-full bg-green-600 mt-2"></div>
                    <div className="flex-1">
                      <p className="text-gray-900 font-medium">{activity.description}</p>
                      <p className="text-sm text-gray-500">{activity.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'match-history':
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Match History</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Date</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Opponent</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Score</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Event</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Result</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {matchHistory.map((match, index) => (
                      <tr key={index}>
                        <td className="px-4 py-3 text-sm text-gray-600">{match.date}</td>
                        <td className="px-4 py-3 text-sm text-gray-900 font-medium">{match.opponent}</td>
                        <td className="px-4 py-3 text-sm text-gray-600">{match.score}</td>
                        <td className="px-4 py-3 text-sm text-gray-600">{match.event}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            match.result === 'W' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {match.result === 'W' ? 'Win' : 'Loss'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      case 'achievements':
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Badges & Achievements</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {badges.map((badge, index) => (
                <div key={index} className="text-center p-4 border border-gray-200 rounded-lg hover:shadow-md transition">
                  <div className={`w-16 h-16 ${badge.color} rounded-full flex items-center justify-center text-3xl mx-auto mb-2`}>
                    {badge.icon}
                  </div>
                  <p className="text-sm font-medium text-gray-900">{badge.name}</p>
                </div>
              ))}
            </div>
          </div>
        );

      case 'media':
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Feeds & Social Media</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="border border-gray-200 rounded-lg p-4">
                <h4 className="font-semibold mb-2">Instagram</h4>
                <p className="text-sm text-gray-600">Connect your Instagram feed</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-4">
                <h4 className="font-semibold mb-2">X (Twitter)</h4>
                <p className="text-sm text-gray-600">Connect your X feed</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-4">
                <h4 className="font-semibold mb-2">YouTube</h4>
                <p className="text-sm text-gray-600">Link your YouTube channel</p>
              </div>
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Settings</h3>
            <div className="space-y-4 max-w-2xl">
              <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                Edit Profile
              </button>
              <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                Notifications
              </button>
              <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                USTA / UTR Linking
              </button>
              <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                Change Password
              </button>
              <button className="w-full text-left px-4 py-3 border border-red-200 rounded-lg hover:bg-red-50 text-red-600">
                Delete Account
              </button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-start gap-6">
            {/* Profile Photo */}
            <div className="relative">
              <div className="w-32 h-32 rounded-full bg-white/20 flex items-center justify-center overflow-hidden border-4 border-white/30">
                {playerProfile?.profile_image_url ? (
                  <img src={playerProfile.profile_image_url} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <Camera className="w-12 h-12 text-white/60" />
                )}
              </div>
            </div>

            {/* Profile Info */}
            <div className="flex-1">
              <div className="flex items-start justify-between">
                <div>
                  <h1 className="text-3xl font-bold">{playerProfile?.first_name} {playerProfile?.last_name}</h1>
                  <div className="mt-2 flex items-center gap-4 text-white/90">
                    <span>{playerProfile?.city}, {playerProfile?.state}</span>
                    <span>•</span>
                    <span>USTA: 4.5</span>
                    <span>•</span>
                    <span>UTR: 7.2</span>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <button className="px-4 py-2 bg-white text-green-600 rounded-lg font-medium hover:bg-white/90 transition">
                    Challenge
                  </button>
                  <button className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg font-medium transition flex items-center gap-2">
                    <MessageCircle className="w-4 h-4" />
                    Message
                  </button>
                  <button className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg font-medium transition flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    Follow
                  </button>
                </div>
              </div>
              
              {/* Quick Stats Preview */}
              <div className="mt-6 flex gap-6 text-sm">
                <div>
                  <p className="text-white/70">Win Rate</p>
                  <p className="text-xl font-bold">{((stats.wins / stats.matchesPlayed) * 100).toFixed(0)}%</p>
                </div>
                <div>
                  <p className="text-white/70">Matches</p>
                  <p className="text-xl font-bold">{stats.matchesPlayed}</p>
                </div>
                <div>
                  <p className="text-white/70">Rank</p>
                  <p className="text-xl font-bold">#{stats.ladderPosition}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs & Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          {/* Left Sidebar Navigation */}
          <div className="w-64 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-2 sticky top-20">
              <button
                onClick={() => setActiveTab('overview')}
                className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${
                  activeTab === 'overview' ? 'bg-green-50 text-green-600' : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setActiveTab('match-history')}
                className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${
                  activeTab === 'match-history' ? 'bg-green-50 text-green-600' : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                Match History
              </button>
              <button
                onClick={() => setActiveTab('rankings')}
                className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${
                  activeTab === 'rankings' ? 'bg-green-50 text-green-600' : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                Rankings
              </button>
              <button
                onClick={() => setActiveTab('achievements')}
                className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${
                  activeTab === 'achievements' ? 'bg-green-50 text-green-600' : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                Achievements
              </button>
              <button
                onClick={() => setActiveTab('media')}
                className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${
                  activeTab === 'media' ? 'bg-green-50 text-green-600' : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                Media
              </button>
              <button
                onClick={() => setActiveTab('settings')}
                className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${
                  activeTab === 'settings' ? 'bg-green-50 text-green-600' : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Settings
                </div>
              </button>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-1">
            {renderTabContent()}
          </div>
        </div>
      </div>
    </div>
  );
}
