'use client';

import { useState } from 'react';
import { Award, DollarSign, Calendar, Star, Settings, Camera, CheckCircle, TrendingUp, Users, Clock } from 'lucide-react';

interface CoachProfileProps {
  user: any;
  userData: any;
  coachProfile: any;
}

type TabType = 'overview' | 'services' | 'availability' | 'reviews' | 'certifications' | 'kpi' | 'settings';

export default function CoachProfile({ user, userData, coachProfile }: CoachProfileProps) {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  
  // Mock data - replace with real data from your database
  const certifications = [
    { name: 'PTR Certified', verified: true, expires: '2026-01-01' },
    { name: 'USPTA Professional', verified: true, expires: '2025-12-31' },
    { name: 'USTA Certified Coach', verified: false, expires: null }
  ];

  const services = [
    { title: 'Private Lesson', duration: '60 min', price: 75, description: 'One-on-one coaching session' },
    { title: 'Group Clinic', duration: '90 min', price: 45, description: 'Group training (4-6 players)' },
    { title: 'Video Analysis', duration: '30 min', price: 50, description: 'Professional video breakdown' }
  ];

  const packages = [
    { name: '5-Lesson Pack', price: 350, savings: 25 },
    { name: '10-Lesson Pack', price: 650, savings: 100 },
    { name: 'Seasonal Program', price: 1200, savings: 300 }
  ];

  const reviews = [
    { student: 'John Doe', rating: 5, comment: 'Excellent coach! Improved my serve significantly.', date: '2 weeks ago' },
    { student: 'Jane Smith', rating: 5, comment: 'Very patient and knowledgeable.', date: '1 month ago' }
  ];

  const kpiData = {
    totalSessions: 156,
    revenue: 11700,
    newStudents: 23,
    retentionRate: 87
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            {/* Coach Stats */}
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Sessions</p>
                    <p className="text-2xl font-bold text-gray-900">{kpiData.totalSessions}</p>
                  </div>
                  <Calendar className="w-8 h-8 text-green-600" />
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Revenue</p>
                    <p className="text-2xl font-bold text-gray-900">${kpiData.revenue}</p>
                  </div>
                  <DollarSign className="w-8 h-8 text-yellow-600" />
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">New Students</p>
                    <p className="text-2xl font-bold text-gray-900">{kpiData.newStudents}</p>
                  </div>
                  <Users className="w-8 h-8 text-blue-600" />
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Retention Rate</p>
                    <p className="text-2xl font-bold text-gray-900">{kpiData.retentionRate}%</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-purple-600" />
                </div>
              </div>
            </div>

            {/* Coach Bio */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">About Me</h3>
              <p className="text-gray-700 mb-4">{coachProfile?.bio || 'Professional tennis coach with years of experience.'}</p>
              
              <div className="grid md:grid-cols-2 gap-4 mt-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Coaching Experience</h4>
                  <p className="text-gray-700 text-sm">{coachProfile?.coaching_experience_description || 'Years of experience coaching players of all levels.'}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Teaching Style</h4>
                  <p className="text-gray-700 text-sm">{coachProfile?.teaching_style_description || 'Patient, technique-focused approach.'}</p>
                </div>
              </div>
              
              {coachProfile?.achievements && (
                <div className="mt-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Achievements</h4>
                  <p className="text-gray-700 text-sm">{coachProfile.achievements}</p>
                </div>
              )}
            </div>

            {/* Player Types Coached */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Player Types I Coach</h3>
              <div className="flex flex-wrap gap-2">
                {coachProfile?.player_types_coached?.map((type: string, index: number) => (
                  <span key={index} className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                    {type}
                  </span>
                ))}
              </div>
            </div>
          </div>
        );

      case 'services':
        return (
          <div className="space-y-6">
            {/* Service Cards */}
            <div className="grid md:grid-cols-3 gap-6">
              {services.map((service, index) => (
                <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{service.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">{service.description}</p>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2 text-gray-600">
                      <Clock className="w-4 h-4" />
                      <span className="text-sm">{service.duration}</span>
                    </div>
                    <span className="text-2xl font-bold text-green-600">${service.price}</span>
                  </div>
                  <button className="w-full py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition font-medium">
                    Book Now
                  </button>
                </div>
              ))}
            </div>

            {/* Package Deals */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Package Deals</h3>
              <div className="grid md:grid-cols-3 gap-4">
                {packages.map((pkg, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 hover:border-green-600 transition">
                    <h4 className="font-semibold text-gray-900 mb-2">{pkg.name}</h4>
                    <div className="mb-2">
                      <span className="text-2xl font-bold text-gray-900">${pkg.price}</span>
                      <span className="ml-2 text-sm text-green-600">Save ${pkg.savings}</span>
                    </div>
                    <button className="w-full py-2 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition text-sm font-medium">
                      Select Package
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'availability':
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Weekly Availability</h3>
            <div className="border border-gray-200 rounded-lg p-6 text-center">
              <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Calendar integration coming soon</p>
              <p className="text-sm text-gray-500 mt-2">View and manage your coaching schedule</p>
            </div>
          </div>
        );

      case 'reviews':
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Student Reviews</h3>
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                <span className="text-xl font-bold">4.9</span>
                <span className="text-gray-600">({reviews.length} reviews)</span>
              </div>
            </div>
            
            <div className="space-y-4">
              {reviews.map((review, index) => (
                <div key={index} className="border-b last:border-0 pb-4 last:pb-0">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="font-semibold text-gray-900">{review.student}</p>
                      <div className="flex items-center gap-1 mt-1">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className={`w-4 h-4 ${i < review.rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'}`} />
                        ))}
                      </div>
                    </div>
                    <span className="text-sm text-gray-500">{review.date}</span>
                  </div>
                  <p className="text-gray-700">{review.comment}</p>
                </div>
              ))}
            </div>
          </div>
        );

      case 'certifications':
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Certifications & Licenses</h3>
            <div className="space-y-4">
              {certifications.map((cert, index) => (
                <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center gap-3">
                    {cert.verified ? (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    ) : (
                      <div className="w-6 h-6 rounded-full border-2 border-gray-300"></div>
                    )}
                    <div>
                      <p className="font-semibold text-gray-900">{cert.name}</p>
                      {cert.expires && (
                        <p className="text-sm text-gray-600">Expires: {cert.expires}</p>
                      )}
                    </div>
                  </div>
                  {cert.verified && (
                    <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                      Verified
                    </span>
                  )}
                </div>
              ))}
              
              <button className="w-full py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-green-600 hover:text-green-600 transition">
                + Upload New Certification
              </button>
            </div>
          </div>
        );

      case 'kpi':
        return (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">Coach KPI Dashboard</h3>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-3xl font-bold text-green-600">{kpiData.totalSessions}</p>
                  <p className="text-sm text-gray-600 mt-1">Total Sessions</p>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <p className="text-3xl font-bold text-blue-600">${kpiData.revenue}</p>
                  <p className="text-sm text-gray-600 mt-1">Total Revenue</p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <p className="text-3xl font-bold text-purple-600">{kpiData.newStudents}</p>
                  <p className="text-sm text-gray-600 mt-1">New Students</p>
                </div>
                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <p className="text-3xl font-bold text-yellow-600">{kpiData.retentionRate}%</p>
                  <p className="text-sm text-gray-600 mt-1">Retention Rate</p>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <p className="text-sm text-gray-600">Analytics and detailed reports coming soon</p>
              </div>
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Coach Settings</h3>
            <div className="space-y-4 max-w-2xl">
              <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                Edit Profile
              </button>
              <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                Manage Services & Rates
              </button>
              <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                Availability Settings
              </button>
              <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                Notifications
              </button>
              <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                Payment Settings
              </button>
              <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                Change Password
              </button>
              <button className="w-full text-left px-4 py-3 border border-red-200 rounded-lg hover:bg-red-50 text-red-600">
                Delete Account
              </button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Coach Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-start gap-6">
            {/* Coach Photo */}
            <div className="relative">
              <div className="w-32 h-32 rounded-full bg-white/20 flex items-center justify-center overflow-hidden border-4 border-white/30">
                {coachProfile?.profile_image_url ? (
                  <img src={coachProfile.profile_image_url} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <Camera className="w-12 h-12 text-white/60" />
                )}
              </div>
            </div>

            {/* Coach Info */}
            <div className="flex-1">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3">
                    <h1 className="text-3xl font-bold">{coachProfile?.first_name} {coachProfile?.last_name}</h1>
                    <CheckCircle className="w-6 h-6 text-green-400" title="Verified Coach" />
                  </div>
                  
                  {/* Certification Badges */}
                  <div className="mt-2 flex items-center gap-2">
                    <span className="px-2 py-1 bg-white/20 rounded text-xs font-medium">PTR Certified</span>
                    <span className="px-2 py-1 bg-white/20 rounded text-xs font-medium">USPTA Professional</span>
                  </div>
                  
                  <div className="mt-3 flex items-center gap-4 text-white/90">
                    <span>{coachProfile?.years_experience || 0} years experience</span>
                    <span>•</span>
                    <span>{coachProfile?.coach_type}</span>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <button className="px-4 py-2 bg-white text-blue-600 rounded-lg font-medium hover:bg-white/90 transition">
                    Book Session
                  </button>
                </div>
              </div>
              
              {/* Quick Stats Preview */}
              <div className="mt-6 flex gap-6 text-sm">
                <div>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    <span className="text-xl font-bold">4.9</span>
                  </div>
                  <p className="text-white/70">Rating</p>
                </div>
                <div>
                  <p className="text-xl font-bold">{kpiData.totalSessions}</p>
                  <p className="text-white/70">Sessions</p>
                </div>
                <div>
                  <p className="text-xl font-bold">{kpiData.newStudents}</p>
                  <p className="text-white/70">Students</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs & Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          {/* Left Sidebar Navigation */}
          <div className="w-64 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-2 sticky top-20">
              <button onClick={() => setActiveTab('overview')} className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${activeTab === 'overview' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>Overview</button>
              <button onClick={() => setActiveTab('services')} className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${activeTab === 'services' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>Services & Rates</button>
              <button onClick={() => setActiveTab('availability')} className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${activeTab === 'availability' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>Availability</button>
              <button onClick={() => setActiveTab('reviews')} className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${activeTab === 'reviews' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>Student Reviews</button>
              <button onClick={() => setActiveTab('certifications')} className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${activeTab === 'certifications' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>Certifications</button>
              <button onClick={() => setActiveTab('kpi')} className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${activeTab === 'kpi' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>KPI Dashboard</button>
              <button onClick={() => setActiveTab('settings')} className={`w-full text-left px-4 py-2 rounded-lg font-medium transition ${activeTab === 'settings' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>
                <div className="flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Settings
                </div>
              </button>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-1">
            {renderTabContent()}
          </div>
        </div>
      </div>
    </div>
  );
}
