# Tennis Platform Backend API

NestJS backend API for the Tennis Platform with authentication, RBAC, and Supabase integration.

## Features

- JWT Authentication
- Role-Based Access Control (Player, Coach, ClubAdmin, SuperAdmin)
- Supabase PostgreSQL database
- Swagger API Documentation
- RESTful API endpoints
- Password hashing with bcrypt

## Tech Stack

- NestJS 10
- TypeScript
- Supabase (PostgreSQL)
- JWT & Passport
- Swagger/OpenAPI
- Class Validator

## Setup

1. Install dependencies:
```bash
npm install
```

2. Configure environment variables:
```bash
cp .env.example .env
```

Edit `.env` and add your Supabase credentials:
```
PORT=3001
NODE_ENV=development

SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key

JWT_SECRET=your_jwt_secret_key_change_this_in_production
JWT_EXPIRES_IN=7d
```

3. Start the development server:
```bash
npm run start:dev
```

4. Access the API:
- API: http://localhost:3001
- Swagger Docs: http://localhost:3001/api

## API Endpoints

### Authentication
- `POST /auth/register` - Register a new user
- `POST /auth/login` - Login user
- `GET /auth/me` - Get current user (requires auth)

### Users
- `GET /users` - Get all users
- `GET /users/:id` - Get user by ID

### Coaches
- `GET /coaches` - Get all coaches
- `GET /coaches/:id` - Get coach by ID
- `GET /coaches?specialties=singles&location=NYC` - Search coaches

### Bookings
- `GET /bookings` - Get all bookings
- `GET /bookings/:id` - Get booking by ID
- `GET /bookings/player/:playerId` - Get bookings for a player
- `GET /bookings/coach/:coachId` - Get bookings for a coach

### Clubs
- `GET /clubs` - Get all clubs
- `GET /clubs/:id` - Get club by ID
- `GET /clubs/:id/courts` - Get courts for a club

## User Roles

- **Player** - Regular users who book courts and coaches
- **Coach** - Tennis instructors who can be booked
- **ClubAdmin** - Manage club facilities and courts
- **SuperAdmin** - Full system access

## Development

```bash
# Run in development mode
npm run start:dev

# Build for production
npm run build

# Run in production mode
npm run start:prod

# Run tests
npm run test

# Run linter
npm run lint
```

## Database

The backend uses Supabase with the following main tables:
- users
- player_profiles
- coach_profiles
- clubs
- courts
- bookings
- tournaments
- matches
- reviews

See `/supabase/migrations` for the complete schema.
