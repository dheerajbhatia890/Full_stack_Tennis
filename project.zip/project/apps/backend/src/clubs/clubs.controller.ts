import { Controller, Get, Param } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { ClubsService } from './clubs.service';

@ApiTags('Clubs')
@Controller('clubs')
export class ClubsController {
  constructor(private readonly clubsService: ClubsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all clubs' })
  findAll() {
    return this.clubsService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get club by ID' })
  findOne(@Param('id') id: string) {
    return this.clubsService.findOne(id);
  }

  @Get(':id/courts')
  @ApiOperation({ summary: 'Get courts for a club' })
  findCourts(@Param('id') id: string) {
    return this.clubsService.findCourts(id);
  }
}
