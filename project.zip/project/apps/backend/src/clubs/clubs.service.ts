import { Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';

@Injectable()
export class ClubsService {
  constructor(private supabaseService: SupabaseService) {}

  async findAll() {
    const supabase = this.supabaseService.getClient();
    const { data, error } = await supabase
      .from('clubs')
      .select(`
        *,
        admin:users!clubs_admin_user_id_fkey(id, first_name, last_name, email)
      `);

    if (error) throw error;
    return data;
  }

  async findOne(id: string) {
    const supabase = this.supabaseService.getClient();
    const { data, error } = await supabase
      .from('clubs')
      .select(`
        *,
        admin:users!clubs_admin_user_id_fkey(id, first_name, last_name, email),
        courts(*)
      `)
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  }

  async findCourts(clubId: string) {
    const supabase = this.supabaseService.getClient();
    const { data, error } = await supabase
      .from('courts')
      .select('*')
      .eq('club_id', clubId);

    if (error) throw error;
    return data;
  }
}
