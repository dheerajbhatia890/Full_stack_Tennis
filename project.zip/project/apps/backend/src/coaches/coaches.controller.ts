import { Controller, Get, Param, Query } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { CoachesService } from './coaches.service';

@ApiTags('Coaches')
@Controller('coaches')
export class CoachesController {
  constructor(private readonly coachesService: CoachesService) {}

  @Get()
  @ApiOperation({ summary: 'Get all coaches' })
  @ApiQuery({ name: 'specialties', required: false })
  @ApiQuery({ name: 'location', required: false })
  findAll(@Query() query: { specialties?: string; location?: string }) {
    if (query.specialties || query.location) {
      return this.coachesService.search(query);
    }
    return this.coachesService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get coach by ID' })
  findOne(@Param('id') id: string) {
    return this.coachesService.findOne(id);
  }
}
