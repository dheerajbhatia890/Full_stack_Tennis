import { Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';

@Injectable()
export class CoachesService {
  constructor(private supabaseService: SupabaseService) {}

  async findAll() {
    const supabase = this.supabaseService.getClient();
    const { data, error } = await supabase
      .from('coach_profiles')
      .select(`
        *,
        users!inner(id, email, first_name, last_name)
      `);

    if (error) throw error;
    return data;
  }

  async findOne(id: string) {
    const supabase = this.supabaseService.getClient();
    const { data, error } = await supabase
      .from('coach_profiles')
      .select(`
        *,
        users!inner(id, email, first_name, last_name)
      `)
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  }

  async search(query: { specialties?: string; location?: string }) {
    const supabase = this.supabaseService.getClient();
    let request = supabase
      .from('coach_profiles')
      .select(`
        *,
        users!inner(id, email, first_name, last_name)
      `);

    if (query.specialties) {
      request = request.contains('specialties', [query.specialties]);
    }

    if (query.location) {
      request = request.ilike('location', `%${query.location}%`);
    }

    const { data, error } = await request;

    if (error) throw error;
    return data;
  }
}
