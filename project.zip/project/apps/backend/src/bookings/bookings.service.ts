import { Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';

@Injectable()
export class BookingsService {
  constructor(private supabaseService: SupabaseService) {}

  async findAll() {
    const supabase = this.supabaseService.getClient();
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        player:player_profiles(*),
        coach:coach_profiles(*),
        court:courts(*)
      `);

    if (error) throw error;
    return data;
  }

  async findOne(id: string) {
    const supabase = this.supabaseService.getClient();
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        player:player_profiles(*),
        coach:coach_profiles(*),
        court:courts(*)
      `)
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  }

  async findByPlayer(playerId: string) {
    const supabase = this.supabaseService.getClient();
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        coach:coach_profiles(*),
        court:courts(*)
      `)
      .eq('player_id', playerId);

    if (error) throw error;
    return data;
  }

  async findByCoach(coachId: string) {
    const supabase = this.supabaseService.getClient();
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        player:player_profiles(*),
        court:courts(*)
      `)
      .eq('coach_id', coachId);

    if (error) throw error;
    return data;
  }
}
