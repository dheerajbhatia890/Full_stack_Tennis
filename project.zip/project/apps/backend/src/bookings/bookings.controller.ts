import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { BookingsService } from './bookings.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Bookings')
@Controller('bookings')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class BookingsController {
  constructor(private readonly bookingsService: BookingsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all bookings' })
  findAll() {
    return this.bookingsService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get booking by ID' })
  findOne(@Param('id') id: string) {
    return this.bookingsService.findOne(id);
  }

  @Get('player/:playerId')
  @ApiOperation({ summary: 'Get bookings by player ID' })
  findByPlayer(@Param('playerId') playerId: string) {
    return this.bookingsService.findByPlayer(playerId);
  }

  @Get('coach/:coachId')
  @ApiOperation({ summary: 'Get bookings by coach ID' })
  findByCoach(@Param('coachId') coachId: string) {
    return this.bookingsService.findByCoach(coachId);
  }
}
