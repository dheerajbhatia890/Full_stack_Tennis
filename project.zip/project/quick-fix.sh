#!/bin/bash

echo "========================================"
echo "Quick Fix - Building Shared Packages"
echo "========================================"
echo ""
echo "This will build the shared packages that"
echo "the backend needs to import."
echo ""

echo "Building @tennis-platform/types..."
cd packages/types
npm run build
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to build types package"
    echo "Make sure TypeScript is installed in the types package"
    cd ../..
    exit 1
fi
cd ../..
echo "✓ Types package built successfully"
echo ""

echo "Building @tennis-platform/config..."
cd packages/config
npm run build
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to build config package"
    cd ../..
    exit 1
fi
cd ../..
echo "✓ Config package built successfully"
echo ""

echo "Building @tennis-platform/utils..."
cd packages/utils
npm run build
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to build utils package"
    cd ../..
    exit 1
fi
cd ../..
echo "✓ Utils package built successfully"
echo ""

echo "========================================"
echo "Fix Complete!"
echo "========================================"
echo ""
echo "You can now run the backend:"
echo "  cd apps/backend"
echo "  npm run start:dev"
echo ""
