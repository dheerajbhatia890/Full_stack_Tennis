# 🔧 Session & Login Troubleshooting Guide

## Problem
- User signs up and completes player profile, but gets logged out
- When trying to log back in, get error: "Failed to fetch user data"

## 🎯 Immediate Debugging Steps

### Step 1: Check Debug Page
1. Navigate to: `http://localhost:3000/debug`
2. This will show you:
   - Auth user status
   - Session status
   - Database connectivity
   - User record in database
   - Local storage keys

### Step 2: Check Browser Console
1. Open browser console (F12)
2. Try to log in
3. Look for the console.log messages that now appear:
   ```
   Attempting login for: [email]
   Auth successful, user ID: [id]
   Session: Active/No session
   User data fetch result: [data]
   ```

### Step 3: Check Supabase Dashboard
1. Go to your Supabase project dashboard
2. Navigate to **Authentication** → **Users**
3. Find your user - is it there?
4. Navigate to **Table Editor** → **users** table
5. Is there a matching record with the same `id`?

## 🔍 Common Issues & Solutions

### Issue 1: User exists in Auth but not in `users` table

**Symptom:** Can't read user data after login

**Cause:** The `INSERT` into users table failed during registration

**Solution:**
1. Go to Supabase Dashboard → Table Editor → users
2. Manually add the user record:
   ```sql
   INSERT INTO users (id, email, first_name, last_name, roles, onboarding_completed)
   VALUES (
     '[user-id-from-auth]',
     '[email]',
     '[first-name]',
     '[last-name]',
     ARRAY[]::text[],
     false
   );
   ```

Or delete the auth user and re-register.

### Issue 2: RLS Policy Blocking Read

**Symptom:** "Failed to fetch user data" even though user exists

**Cause:** Row Level Security policy isn't allowing read

**Solution:**
Check if RLS is enabled and policies are correct:

```sql
-- Check if RLS is enabled
SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE tablename = 'users';

-- Check policies
SELECT * FROM pg_policies WHERE tablename = 'users';
```

Expected policies:
- `Users can view own profile` (SELECT)
- `Users can update own profile` (UPDATE)
- `Users can create own user record` (INSERT)

### Issue 3: Email Confirmation Required

**Symptom:** User created but can't log in

**Cause:** Supabase project has email confirmation enabled

**Solution:**

**Option A: Disable email confirmation (Development only)**
1. Go to Supabase Dashboard
2. Authentication → Providers → Email
3. Uncheck "Confirm email"
4. Save

**Option B: Confirm emails manually**
1. Go to Authentication → Users
2. Click on user
3. Click "Confirm email"

**Option C: Handle confirmation in code**
Update registration to check for confirmation:
```typescript
if (authData.user && !authData.user.email_confirmed_at) {
  setError('Please check your email and confirm your account before logging in');
  return;
}
```

### Issue 4: Session Not Persisting

**Symptom:** User logs in but immediately loses session

**Cause:** Session storage not configured properly

**Solution:** Already applied in `lib/supabase.ts`:
```typescript
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storageKey: 'tennis-platform-auth',
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
  }
});
```

If still having issues, try:
1. Clear browser localStorage
2. Clear cookies
3. Hard refresh (Ctrl+Shift+R)
4. Try incognito/private mode

### Issue 5: CORS or Network Issues

**Symptom:** Intermittent failures, network errors

**Solution:**
1. Check browser console for CORS errors
2. Verify Supabase URL and keys in `.env.local`
3. Check if Supabase project is paused (free tier)
4. Try from different network

## 🧪 Manual Testing Steps

### Test 1: Can you create auth user?
```typescript
const { data, error } = await supabase.auth.signUp({
  email: 'test@example.com',
  password: 'password123'
});
console.log('SignUp result:', { data, error });
```

### Test 2: Can you read from users table?
```typescript
const { data, error } = await supabase
  .from('users')
  .select('*')
  .limit(1);
console.log('Users query:', { data, error });
```

### Test 3: Can you insert into users table?
```typescript
const { data: { user } } = await supabase.auth.getUser();
if (user) {
  const { data, error } = await supabase
    .from('users')
    .insert({
      id: user.id,
      email: user.email,
      first_name: 'Test',
      last_name: 'User',
      roles: [],
      onboarding_completed: false
    });
  console.log('Insert result:', { data, error });
}
```

## 🔧 Quick Fixes to Try

### Fix 1: Clear Everything and Start Fresh
```bash
# In browser console
localStorage.clear();
location.reload();
```

Then:
1. Delete user from Supabase Auth
2. Delete user from users table (if exists)
3. Re-register with a different email

### Fix 2: Check Environment Variables
Make sure `apps/web/.env.local` has:
```env
NEXT_PUBLIC_SUPABASE_URL=https://[your-project].supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=[your-anon-key]
NEXT_PUBLIC_API_URL=http://localhost:3001
```

### Fix 3: Restart Dev Server
```bash
# Stop web server (Ctrl+C)
# Then restart
npm run dev
```

### Fix 4: Check Supabase Service Role Key
If using service role key for admin operations, make sure it's correct in backend `.env`:
```env
SUPABASE_SERVICE_ROLE_KEY=[your-service-role-key]
```

## 📊 Expected Flow

### Successful Registration Flow:
```
1. User fills registration form
2. supabase.auth.signUp() creates auth user
3. App creates record in users table
4. localStorage stores registration_data
5. Redirect to /onboarding/roles
```

### Successful Login Flow:
```
1. User enters credentials
2. supabase.auth.signInWithPassword() authenticates
3. Session established and persisted
4. App reads from users table (RLS allows because id = auth.uid())
5. Check onboarding status and redirect appropriately
```

## 🆘 If Nothing Works

### Nuclear Option: Reset Everything

1. **Delete all users from Supabase:**
   - Go to Authentication → Users
   - Delete all test users

2. **Truncate users table:**
   ```sql
   TRUNCATE users CASCADE;
   ```

3. **Clear browser:**
   - Clear all localStorage
   - Clear all cookies for localhost
   - Hard refresh

4. **Restart everything:**
   ```bash
   # Stop all servers
   # Restart backend
   cd apps/backend
   npm run start:dev
   
   # Restart web (new terminal)
   cd apps/web
   npm run dev
   ```

5. **Test with new account:**
   - Use a brand new email
   - Complete full registration
   - Check console logs at each step

## 📝 Report Issue Checklist

If you still have issues, gather this info:

1. ✅ Screenshots of browser console errors
2. ✅ Output from `/debug` page
3. ✅ Supabase project ID and region
4. ✅ Whether email confirmation is enabled
5. ✅ Screenshot of Supabase Auth users page
6. ✅ Screenshot of users table in Supabase
7. ✅ Contents of `.env.local` (hide sensitive keys)
8. ✅ Node and npm versions
9. ✅ Browser and version
10. ✅ Exact error message

## 💡 Pro Tips

1. **Always check console logs first** - The updated code now logs every step
2. **Use /debug page** - It shows exactly what's happening
3. **Check Supabase logs** - Dashboard → Logs shows all database queries
4. **Test in incognito** - Rules out browser extension issues
5. **One user at a time** - Don't register multiple test accounts simultaneously

---

**Remember:** The debug page at `/debug` is your best friend for troubleshooting! 🎾
