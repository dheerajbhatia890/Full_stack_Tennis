# Tennis Platform

Full-stack tennis platform connecting players, coaches, and clubs with features for court bookings, tournaments, ladders, and payments.

## Project Structure

```
/apps
  /backend          # NestJS backend API
  /web              # Next.js web application
  /mobile           # React Native mobile app

/packages
  /types            # Shared TypeScript types and Zod schemas
  /utils            # Shared utility functions

/infrastructure
  /terraform        # Infrastructure as Code
  /docker           # Docker configurations
```

## Tech Stack

### Backend
- NestJS (TypeScript)
- Supabase (PostgreSQL + Auth)
- Redis (caching, queues)
- Stripe (payments)
- JWT authentication
- REST API

### Frontend (Web)
- Next.js 14 (App Router)
- TailwindCSS
- Axios for API calls

### Mobile
- React Native with Expo
- React Navigation
- AsyncStorage

## Features

### Authentication & Authorization
- Email/password authentication
- OAuth (Google, Apple) ready
- JWT access + refresh tokens
- Role-Based Access Control (Player, Coach, ClubAdmin, SuperAdmin)

### Core Features (Skeleton Ready)
- User profiles (Players & Coaches)
- Court bookings
- Coach directory and search
- Club management
- Tournament system
- Ladder competitions
- Match tracking
- Payment processing
- Coach payouts
- Notifications
- Chat messaging

## Database Schema

Complete schema with 20+ tables:
- Users & Profiles
- Clubs & Courts
- Bookings & Schedules
- Zones & Packages
- Ladders & Tournaments
- Matches & Reviews
- Payments & Payouts
- Notifications & Chat

## Getting Started

### Prerequisites
- Node.js 18+
- Supabase account
- PostgreSQL with PostGIS

### Setup

1. Install dependencies:
```bash
npm install
cd apps/backend && npm install
cd apps/web && npm install
cd apps/mobile && npm install
cd packages/types && npm install
cd packages/utils && npm install
```

2. Configure environment variables:
```bash
cp apps/backend/.env.example apps/backend/.env
cp apps/web/.env.example apps/web/.env
cp apps/mobile/.env.example apps/mobile/.env
```

3. Update environment files with your Supabase credentials

### Development

Backend:
```bash
cd apps/backend
npm run start:dev
```

Web:
```bash
cd apps/web
npm run dev
```

Mobile:
```bash
cd apps/mobile
npm start
```

## API Documentation

Once the backend is running, access Swagger docs at:
```
http://localhost:3001/api
```

## Key Endpoints

### Authentication
- `POST /auth/register` - Register new user
- `POST /auth/login` - Login
- `POST /auth/refresh` - Refresh token
- `POST /auth/logout` - Logout

### Players
- `GET /players` - List players
- `GET /players/:id` - Get player
- `POST /players/profile` - Create profile
- `PATCH /players/profile` - Update profile

### Coaches
- `GET /coaches` - List coaches
- `GET /coaches/:id` - Get coach
- `POST /coaches/search` - Search coaches

### Bookings
- `POST /bookings` - Create booking
- `GET /bookings/:id` - Get booking
- `PATCH /bookings/:id` - Update booking

## Next Steps

### Backend
- Implement remaining modules (clubs, tournaments, ladders)
- Add WebSocket support for real-time features
- Integrate Stripe for payments
- Add email notifications (SendGrid)
- Add push notifications (OneSignal)

### Frontend
- Build complete UI for all features
- Add responsive design
- Implement real-time updates
- Add file upload for images

### Mobile
- Complete all screens
- Implement navigation flow
- Add offline support
- Integrate push notifications

### Infrastructure
- Complete Terraform configuration
- Set up CI/CD pipeline
- Configure monitoring and logging
- Set up staging and production environments

## Security

- Row Level Security (RLS) enabled on all tables
- JWT authentication with refresh tokens
- Password hashing with bcrypt
- Input validation with Zod
- CORS configuration
- Rate limiting (to be implemented)

## License

Private - All Rights Reserved
