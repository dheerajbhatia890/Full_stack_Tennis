# Tennis Platform - Setup & Troubleshooting Guide

## 🎾 Quick Start

### Automated Setup (Recommended)

**Windows:**
```bash
setup.bat
```

**Linux/Mac:**
```bash
chmod +x setup.sh
./setup.sh
```

### Manual Setup

If you prefer to set up manually or the automated script fails:

1. **Install Root Dependencies**
   ```bash
   npm install
   ```

2. **Install Backend Dependencies**
   ```bash
   cd apps/backend
   npm install
   cd ../..
   ```

3. **Install Web Dependencies**
   ```bash
   cd apps/web
   npm install
   cd ../..
   ```

4. **Install Package Dependencies**
   ```bash
   cd packages/types
   npm install
   cd ../config
   npm install
   cd ../utils
   npm install
   cd ../..
   ```

5. **Build Shared Packages** (CRITICAL STEP!)
   ```bash
   npm run build:packages
   ```
   Or manually:
   ```bash
   cd packages/types
   npm run build
   cd ../config
   npm run build
   cd ../utils
   npm run build
   cd ../..
   ```

## 🚀 Running the Application

### Backend Server
```bash
npm run backend:dev
```
Or from the backend directory:
```bash
cd apps/backend
npm run start:dev
```

### Web Frontend
```bash
npm run web:dev
```
Or from the web directory:
```bash
cd apps/web
npm run dev
```

## 🔧 Common Issues & Solutions

### Issue 1: "Cannot find module '@tennis-platform/types'"

**Cause:** The shared packages haven't been built yet.

**Solution:**
```bash
npm run build:packages
```

### Issue 2: "TS2307: Cannot find module '@tennis-platform/types'"

**Cause:** TypeScript can't resolve the module paths.

**Solutions:**
1. Make sure you've built the packages (see Issue 1)
2. Verify tsconfig-paths is installed in backend:
   ```bash
   cd apps/backend
   npm install tsconfig-paths --save-dev
   ```
3. Check that backend/tsconfig.json has the path mappings configured (should already be set)

### Issue 3: Changes in shared packages not reflecting

**Cause:** The packages need to be rebuilt after changes.

**Solution:**
```bash
npm run build:packages
```

Or for development with auto-rebuild:
```bash
cd packages/types
npm run dev  # Runs tsc --watch
```

### Issue 4: "Error: Cannot find module 'bcrypt'"

**Cause:** Native dependencies not installed properly.

**Solution:**
```bash
cd apps/backend
npm install
npm rebuild bcrypt
```

## 📁 Project Structure

```
tennis-platform/
├── apps/
│   ├── backend/          # NestJS API server
│   ├── web/              # Next.js web application
│   └── mobile/           # React Native mobile app
├── packages/
│   ├── types/            # Shared TypeScript types
│   ├── config/           # Shared configuration
│   └── utils/            # Shared utility functions
├── infrastructure/       # Deployment configs
├── supabase/            # Database migrations & config
└── package.json         # Root workspace configuration
```

## 🔄 Development Workflow

### Making Changes to Shared Packages

1. Navigate to the package:
   ```bash
   cd packages/types  # or config, or utils
   ```

2. Make your changes to files in `src/`

3. Build the package:
   ```bash
   npm run build
   ```

4. Restart your backend/frontend if it's already running

### Running Multiple Services

**Option 1: Separate Terminals**
- Terminal 1: `npm run backend:dev`
- Terminal 2: `npm run web:dev`

**Option 2: Use a process manager like `concurrently`**
Install concurrently globally:
```bash
npm install -g concurrently
```

Then run:
```bash
concurrently "npm run backend:dev" "npm run web:dev"
```

## 🛠 Additional Commands

### Building for Production

**Backend:**
```bash
cd apps/backend
npm run build
npm run start:prod
```

**Web:**
```bash
cd apps/web
npm run build
```

### Running Tests

**Backend:**
```bash
cd apps/backend
npm test
npm run test:watch    # Watch mode
npm run test:cov      # With coverage
```

### Linting & Formatting

**Backend:**
```bash
cd apps/backend
npm run lint
npm run format
```

## 📝 Environment Variables

### Backend (.env)
Create `apps/backend/.env`:
```env
# Supabase
SUPABASE_URL=your_supabase_url
SUPABASE_KEY=your_supabase_key

# JWT
JWT_SECRET=your_jwt_secret_here
JWT_EXPIRES_IN=7d

# Server
PORT=3000
NODE_ENV=development
```

### Web (.env.local)
Create `apps/web/.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
NEXT_PUBLIC_API_URL=http://localhost:3000
```

## 🐛 Debugging

### Enable Debug Logging

**Backend:**
```bash
cd apps/backend
npm run start:debug
```

Then attach your debugger to port 9229.

### TypeScript Issues

Check TypeScript compilation:
```bash
cd apps/backend
npx tsc --noEmit
```

## 📚 Key Technologies

- **Backend:** NestJS, TypeScript, Supabase
- **Frontend:** Next.js, React, Tailwind CSS
- **Mobile:** React Native, Expo
- **Database:** PostgreSQL (via Supabase)
- **Authentication:** JWT, Passport
- **Package Manager:** npm with workspaces

## 🤝 Contributing

1. Make sure all packages are built before running tests
2. Follow the existing code style
3. Write tests for new features
4. Update documentation as needed

## 📞 Getting Help

If you encounter issues not covered here:

1. Check that all dependencies are installed
2. Verify all shared packages are built (`npm run build:packages`)
3. Make sure environment variables are set
4. Try cleaning and reinstalling:
   ```bash
   # Clean node_modules
   rm -rf node_modules apps/*/node_modules packages/*/node_modules
   
   # Clean build outputs
   rm -rf apps/backend/dist packages/*/dist
   
   # Reinstall and rebuild
   npm run setup
   ```

## 🎯 Next Steps

1. ✅ Complete the setup steps above
2. ✅ Configure your environment variables
3. ✅ Set up your Supabase project
4. ✅ Run the backend: `npm run backend:dev`
5. ✅ Run the frontend: `npm run web:dev`
6. 🎾 Start building your tennis platform!

---

**Happy Coding! 🎾**
