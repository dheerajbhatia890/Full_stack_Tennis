# 🎾 Tennis Platform - Quick Start Guide

## 🚨 IMMEDIATE FIX (If Backend Won't Start)

Your backend was failing with: `Cannot find module '@tennis-platform/types'`

### Solution (Choose One):

#### Option A: Automated Fix (Recommended)
**Windows:**
```bash
quick-fix.bat
```

**Linux/Mac:**
```bash
chmod +x quick-fix.sh
./quick-fix.sh
```

#### Option B: Manual Fix
```bash
cd packages/types
npm run build
cd ../config
npm run build
cd ../utils
npm run build
cd ../..
```

After running either option, your backend will start successfully!

---

## 📋 Complete Setup (First Time)

### Step 1: Run Setup Script

**Windows:**
```bash
setup.bat
```

**Linux/Mac:**
```bash
chmod +x setup.sh
./setup.sh
```

This script will:
- ✅ Install all dependencies
- ✅ Build all shared packages
- ✅ Set up the entire monorepo

### Step 2: Configure Environment Variables

1. **Backend Configuration**
   ```bash
   cd apps/backend
   cp .env.example .env
   ```
   
   Edit `.env` and update:
   - `SUPABASE_URL`
   - `SUPABASE_KEY`
   - `JWT_SECRET` (use a strong random string)

2. **Web Configuration**
   ```bash
   cd apps/web
   cp .env.example .env.local
   ```
   
   Edit `.env.local` and update:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`

### Step 3: Start the Backend

From project root:
```bash
npm run backend:dev
```

Or from backend directory:
```bash
cd apps/backend
npm run start:dev
```

Expected output:
```
[INFO] ts-node-dev ver. 2.0.0
[Nest] INFO [NestFactory] Starting Nest application...
[Nest] INFO [InstanceLoader] AppModule dependencies initialized
[Nest] INFO Application is running on: http://localhost:3001
```

### Step 4: Start the Web Frontend (Optional)

In a new terminal:
```bash
npm run web:dev
```

Or:
```bash
cd apps/web
npm run dev
```

---

## 🎯 Verify Everything Works

1. **Backend Health Check:**
   - Open browser: http://localhost:3001
   - Should see: "Tennis Platform API"

2. **API Documentation:**
   - Open browser: http://localhost:3001/api
   - Should see Swagger documentation

3. **Test Authentication:**
   ```bash
   curl -X POST http://localhost:3001/auth/register \
     -H "Content-Type: application/json" \
     -d '{
       "email": "test@example.com",
       "password": "SecurePass123!",
       "firstName": "Test",
       "lastName": "User",
       "role": "Player"
     }'
   ```

---

## 🔧 Common Commands

### Development
```bash
# Start backend
npm run backend:dev

# Start web frontend
npm run web:dev

# Build all packages
npm run build:packages
```

### When You Make Changes to Shared Packages
```bash
# Rebuild a specific package
cd packages/types
npm run build

# Or rebuild all packages from root
npm run build:packages
```

---

## 📁 Key Files & Directories

```
project/
├── apps/
│   ├── backend/          # Your NestJS API (Port 3001)
│   │   ├── src/
│   │   │   ├── auth/     # Authentication endpoints
│   │   │   ├── users/    # User management
│   │   │   ├── bookings/ # Booking system
│   │   │   ├── coaches/  # Coach profiles
│   │   │   └── clubs/    # Club management
│   │   └── .env          # Backend config (create from .env.example)
│   │
│   └── web/              # Next.js web app (Port 3000)
│       └── .env.local    # Web config (create from .env.example)
│
└── packages/
    ├── types/            # Shared TypeScript types
    ├── config/           # Shared configuration
    └── utils/            # Shared utilities
```

---

## ❓ Troubleshooting

### "Cannot find module '@tennis-platform/types'"
**Solution:** Run `quick-fix.bat` (Windows) or `./quick-fix.sh` (Linux/Mac)

### "Port 3001 already in use"
**Solution:** 
```bash
# Windows
netstat -ano | findstr :3001
taskkill /PID <PID> /F

# Linux/Mac
lsof -ti:3001 | xargs kill -9
```

### "npm ERR! peer dependencies"
**Solution:** Install with legacy peer deps
```bash
npm install --legacy-peer-deps
```

### Backend starts but crashes immediately
**Solution:** Check your `.env` file has all required variables:
- SUPABASE_URL
- SUPABASE_KEY  
- JWT_SECRET

---

## 📚 What's Next?

1. ✅ Backend is running
2. ✅ You can access Swagger docs
3. 🚀 Start implementing features!

### Key Features Already Set Up:
- ✅ User authentication (register/login)
- ✅ JWT token management
- ✅ Role-based access control
- ✅ Database integration (Supabase)
- ✅ Swagger API documentation
- ✅ CORS configuration
- ✅ Validation with class-validator

### Ready to Build:
- Court booking system
- Coach profiles & search
- Club management
- Tournament system
- Match tracking
- Payment processing
- Notifications

---

## 🆘 Need More Help?

### Documentation Files:
- **FIXES_SUMMARY.md** - Detailed explanation of all fixes
- **SETUP_GUIDE.md** - Comprehensive setup and troubleshooting
- **README.md** - Project overview and features

### Check Logs:
Backend logs will show detailed error messages:
```bash
cd apps/backend
npm run start:dev
# Watch the console output
```

---

## ✨ Pro Tips

### Development Workflow:
1. Make changes to code
2. Backend auto-reloads (ts-node-dev --respawn)
3. If you change shared packages, rebuild them
4. Test your endpoints in Swagger UI

### Efficient Package Rebuilding:
```bash
# Watch mode for continuous rebuilding
cd packages/types
npm run dev  # Runs tsc --watch
```

### Multiple Services at Once:
```bash
# Install concurrently globally
npm install -g concurrently

# Run both backend and frontend
concurrently "npm run backend:dev" "npm run web:dev"
```

---

## 🎉 You're Ready!

Your tennis platform is now properly set up and ready for development. Happy coding! 🎾

For detailed information, see:
- **SETUP_GUIDE.md** for comprehensive setup instructions
- **FIXES_SUMMARY.md** for technical details about fixes
- **README.md** for project overview

---

**Last Updated:** December 2024
**Project Status:** Development Ready ✅
