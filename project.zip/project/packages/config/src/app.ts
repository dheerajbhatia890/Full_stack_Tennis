export interface AppConfig {
  name: string;
  version: string;
  description: string;
  pagination: {
    defaultLimit: number;
    maxLimit: number;
  };
  booking: {
    minDurationMinutes: number;
    maxDurationMinutes: number;
    defaultDurationMinutes: number;
    advanceBookingDays: number;
  };
  ratings: {
    min: number;
    max: number;
  };
  uploads: {
    maxFileSize: number;
    allowedImageTypes: string[];
    allowedDocumentTypes: string[];
  };
  cache: {
    ttl: number;
    maxSize: number;
  };
}

export const appConfig: AppConfig = {
  name: 'Tennis Platform',
  version: '1.0.0',
  description: 'Platform for tennis players, coaches, and clubs',
  pagination: {
    defaultLimit: 10,
    maxLimit: 100,
  },
  booking: {
    minDurationMinutes: 30,
    maxDurationMinutes: 240,
    defaultDurationMinutes: 60,
    advanceBookingDays: 30,
  },
  ratings: {
    min: 1,
    max: 5,
  },
  uploads: {
    maxFileSize: 5 * 1024 * 1024,
    allowedImageTypes: ['image/jpeg', 'image/png', 'image/webp'],
    allowedDocumentTypes: ['application/pdf'],
  },
  cache: {
    ttl: 3600,
    maxSize: 100,
  },
};
