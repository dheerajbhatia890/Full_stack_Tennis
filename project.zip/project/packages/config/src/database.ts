export interface DatabaseConfig {
  tables: {
    users: string;
    playerProfiles: string;
    coachProfiles: string;
    clubs: string;
    courts: string;
    bookings: string;
    tournaments: string;
    matches: string;
    reviews: string;
  };
  poolConfig: {
    min: number;
    max: number;
    idleTimeoutMillis: number;
  };
}

export const databaseConfig: DatabaseConfig = {
  tables: {
    users: 'users',
    playerProfiles: 'player_profiles',
    coachProfiles: 'coach_profiles',
    clubs: 'clubs',
    courts: 'courts',
    bookings: 'bookings',
    tournaments: 'tournaments',
    matches: 'matches',
    reviews: 'reviews',
  },
  poolConfig: {
    min: 2,
    max: 10,
    idleTimeoutMillis: 30000,
  },
};
