# @tennis-platform/config

Shared configuration for the Tennis Platform.

## Features

- Environment configuration management
- Database configuration
- Application settings
- Type-safe config interfaces

## Installation

```bash
npm install
npm run build
```

## Usage

### Environment Configuration

```typescript
import { getEnvConfig, validateEnvConfig } from '@tennis-platform/config';

const config = getEnvConfig();
validateEnvConfig(config);

console.log(config.supabase.url);
console.log(config.jwt.secret);
```

### Database Configuration

```typescript
import { databaseConfig } from '@tennis-platform/config';

console.log(databaseConfig.tables.users); // "users"
console.log(databaseConfig.poolConfig.max); // 10
```

### Application Configuration

```typescript
import { appConfig } from '@tennis-platform/config';

console.log(appConfig.name); // "Tennis Platform"
console.log(appConfig.pagination.defaultLimit); // 10
console.log(appConfig.booking.minDurationMinutes); // 30
```

## Available Configs

### Environment Config
- `nodeEnv` - Current environment
- `port` - Server port
- `apiUrl` - API base URL
- `frontendUrl` - Frontend URL
- `supabase` - Supabase credentials
- `jwt` - JWT configuration

### Database Config
- `tables` - Table name constants
- `poolConfig` - Connection pool settings

### App Config
- `name` - Application name
- `version` - Application version
- `pagination` - Pagination defaults
- `booking` - Booking constraints
- `ratings` - Rating ranges
- `uploads` - File upload settings
- `cache` - Cache settings

## Development

```bash
# Build config
npm run build

# Watch mode
npm run dev
```
