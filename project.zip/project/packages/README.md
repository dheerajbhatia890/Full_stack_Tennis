# Tennis Platform Packages

Shared packages for the Tennis Platform monorepo.

## Structure

```
packages/
├── types/          # Shared TypeScript types and interfaces
├── utils/          # Shared utility functions and helpers
└── config/         # Shared configuration
```

## Packages

### @tennis-platform/types

Comprehensive TypeScript types for the entire platform.

**Features:**
- User roles and authentication types
- Player and Coach profile interfaces
- Club and Court types
- Booking management types
- Tournament and Match types
- Review system types
- API response types

**Key Types:**
- `UserRole` - Enum for user roles (Player, Coach, ClubAdmin, SuperAdmin)
- `User`, `PlayerProfile`, `CoachProfile` - User-related interfaces
- `Club`, `Court` - Facility management types
- `Booking`, `Tournament`, `Match` - Event management types
- `ApiResponse`, `PaginatedResponse` - API response types

### @tennis-platform/utils

Utility functions and helpers used across the platform.

**Features:**
- Input validators (email, phone, password, URL, etc.)
- Formatters (currency, date, time, names, etc.)
- Helper functions (permissions, time slots, calculations)
- Constants (API endpoints, error messages, regex patterns)

**Key Functions:**
- `isValidEmail()`, `isValidPassword()` - Validation
- `formatCurrency()`, `formatDate()` - Formatting
- `hasPermission()`, `isAdmin()` - Permission checks
- `calculateAge()`, `calculateDuration()` - Calculations
- `generateTimeSlots()`, `isTimeSlotAvailable()` - Booking helpers

### @tennis-platform/config

Shared configuration for backend and frontend.

**Features:**
- Environment configuration management
- Database configuration
- Application settings
- Type-safe config interfaces

**Key Configs:**
- `getEnvConfig()` - Environment variables
- `databaseConfig` - Database table names and pool settings
- `appConfig` - Application-wide settings

## Installation

Install dependencies for all packages:

```bash
# From the root of the project
npm install

# Or install for each package individually
cd packages/types && npm install && npm run build
cd ../utils && npm install && npm run build
cd ../config && npm install && npm run build
```

## Usage in Apps

### Backend (NestJS)

```typescript
// Import types
import { UserRole, User, Booking } from '@tennis-platform/types';

// Import utilities
import { hasPermission, formatDate } from '@tennis-platform/utils';

// Import config
import { getEnvConfig } from '@tennis-platform/config';

const config = getEnvConfig();
console.log(config.supabase.url);
```

### Web Frontend (Next.js)

```typescript
// Import types
import { User, CoachProfile, ApiResponse } from '@tennis-platform/types';

// Import utilities
import { formatCurrency, isValidEmail } from '@tennis-platform/utils';

// Import constants
import { API_ENDPOINTS } from '@tennis-platform/utils';

const apiUrl = API_ENDPOINTS.AUTH.LOGIN;
```

### Mobile (React Native)

```typescript
// Import types
import { Booking, Tournament, UserRole } from '@tennis-platform/types';

// Import utilities
import { formatDateTime, hasPermission } from '@tennis-platform/utils';
```

## Development

### Building Packages

```bash
# Build all packages
npm run build

# Build specific package
cd packages/types && npm run build

# Watch mode for development
cd packages/types && npm run dev
```

### Adding New Types

1. Add types to the appropriate file in `packages/types/src/`
2. Export from `packages/types/src/index.ts`
3. Build the package: `npm run build`
4. Use in apps: `import { NewType } from '@tennis-platform/types'`

### Adding New Utilities

1. Add functions to the appropriate file in `packages/utils/src/`
2. Export from `packages/utils/src/index.ts`
3. Build the package: `npm run build`
4. Use in apps: `import { newFunction } from '@tennis-platform/utils'`

## Package Linking

All packages use local file references in package.json:

```json
{
  "dependencies": {
    "@tennis-platform/types": "file:../../packages/types",
    "@tennis-platform/utils": "file:../../packages/utils",
    "@tennis-platform/config": "file:../../packages/config"
  }
}
```

This ensures that changes to shared packages are immediately available across all apps.

## Best Practices

1. **Keep packages focused** - Each package has a single responsibility
2. **Export everything through index.ts** - Central export point
3. **Document all types and functions** - Add JSDoc comments
4. **Version packages together** - All packages share the same version
5. **Build before using** - Always build packages after changes

## TypeScript Configuration

All packages share similar TypeScript configuration:

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "declaration": true,
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true
  }
}
```

## Contributing

When adding new shared code:

1. Determine the appropriate package (types, utils, or config)
2. Add the code to the package
3. Update the package's README
4. Build the package
5. Update consuming apps if needed
