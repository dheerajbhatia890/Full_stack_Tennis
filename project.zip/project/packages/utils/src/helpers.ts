import { UserRole } from '@tennis-platform/types';

export const hasPermission = (userRole: UserRole, requiredRole: UserRole): boolean => {
  const roleHierarchy: Record<UserRole, number> = {
    [UserRole.Player]: 1,
    [UserRole.Coach]: 2,
    [UserRole.ClubAdmin]: 3,
    [UserRole.SuperAdmin]: 4,
  };

  return roleHierarchy[userRole] >= roleHierarchy[requiredRole];
};

export const isAdmin = (userRole: UserRole): boolean => {
  return userRole === UserRole.ClubAdmin || userRole === UserRole.SuperAdmin;
};

export const isSuperAdmin = (userRole: UserRole): boolean => {
  return userRole === UserRole.SuperAdmin;
};

export const calculateAge = (dateOfBirth: string): number => {
  const today = new Date();
  const birthDate = new Date(dateOfBirth);
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();

  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }

  return age;
};

export const calculateDuration = (startTime: string, endTime: string): number => {
  const start = new Date(startTime);
  const end = new Date(endTime);
  return Math.round((end.getTime() - start.getTime()) / (1000 * 60));
};

export const generateTimeSlots = (
  startHour: number,
  endHour: number,
  intervalMinutes: number = 60
): string[] => {
  const slots: string[] = [];

  for (let hour = startHour; hour < endHour; hour++) {
    for (let minute = 0; minute < 60; minute += intervalMinutes) {
      const timeSlot = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
      slots.push(timeSlot);
    }
  }

  return slots;
};

export const isTimeSlotAvailable = (
  bookings: Array<{ startTime: string; endTime: string }>,
  newStartTime: string,
  newEndTime: string
): boolean => {
  const newStart = new Date(newStartTime);
  const newEnd = new Date(newEndTime);

  return !bookings.some((booking) => {
    const start = new Date(booking.startTime);
    const end = new Date(booking.endTime);

    return (
      (newStart >= start && newStart < end) ||
      (newEnd > start && newEnd <= end) ||
      (newStart <= start && newEnd >= end)
    );
  });
};

export const sortByDate = <T extends { createdAt: string }>(
  items: T[],
  order: 'asc' | 'desc' = 'desc'
): T[] => {
  return [...items].sort((a, b) => {
    const dateA = new Date(a.createdAt).getTime();
    const dateB = new Date(b.createdAt).getTime();
    return order === 'asc' ? dateA - dateB : dateB - dateA;
  });
};

export const groupBy = <T>(array: T[], key: keyof T): Record<string, T[]> => {
  return array.reduce((result, item) => {
    const groupKey = String(item[key]);
    if (!result[groupKey]) {
      result[groupKey] = [];
    }
    result[groupKey].push(item);
    return result;
  }, {} as Record<string, T[]>);
};

export const debounce = <T extends (...args: any[]) => any>(
  func: T,
  wait: number
): ((...args: Parameters<T>) => void) => {
  let timeout: NodeJS.Timeout;

  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
};

export const generateSlug = (text: string): string => {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim();
};
