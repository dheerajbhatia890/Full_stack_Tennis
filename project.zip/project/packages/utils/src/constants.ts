export const DATE_FORMATS = {
  SHORT: 'MM/DD/YYYY',
  LONG: 'MMMM DD, YYYY',
  ISO: 'YYYY-MM-DD',
  TIME: 'HH:mm',
  DATETIME: 'MM/DD/YYYY HH:mm',
} as const;

export const REGEX_PATTERNS = {
  EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  PHONE: /^\+?[\d\s-()]+$/,
  URL: /^https?:\/\/.+/,
  PASSWORD: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/,
} as const;

export const PAGINATION_DEFAULTS = {
  PAGE: 1,
  LIMIT: 10,
  MAX_LIMIT: 100,
} as const;

export const RATING_RANGE = {
  MIN: 1,
  MAX: 5,
} as const;

export const SKILL_RATING_RANGE = {
  MIN: 0,
  MAX: 10,
} as const;

export const BOOKING_DURATION = {
  MIN_MINUTES: 30,
  MAX_MINUTES: 240,
  DEFAULT_MINUTES: 60,
} as const;

export const COURT_OPERATING_HOURS = {
  DEFAULT_OPEN: 6,
  DEFAULT_CLOSE: 22,
} as const;

export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: '/auth/login',
    REGISTER: '/auth/register',
    LOGOUT: '/auth/logout',
    ME: '/auth/me',
  },
  USERS: '/users',
  COACHES: '/coaches',
  BOOKINGS: '/bookings',
  CLUBS: '/clubs',
  COURTS: '/courts',
  TOURNAMENTS: '/tournaments',
  MATCHES: '/matches',
  REVIEWS: '/reviews',
} as const;

export const ERROR_MESSAGES = {
  UNAUTHORIZED: 'You are not authorized to perform this action',
  NOT_FOUND: 'Resource not found',
  VALIDATION_ERROR: 'Validation error',
  SERVER_ERROR: 'Internal server error',
  INVALID_CREDENTIALS: 'Invalid email or password',
  EMAIL_EXISTS: 'Email already exists',
  BOOKING_CONFLICT: 'Time slot is not available',
  INVALID_DATE_RANGE: 'Invalid date range',
} as const;

export const SUCCESS_MESSAGES = {
  LOGIN: 'Successfully logged in',
  REGISTER: 'Successfully registered',
  LOGOUT: 'Successfully logged out',
  CREATED: 'Successfully created',
  UPDATED: 'Successfully updated',
  DELETED: 'Successfully deleted',
  BOOKING_CONFIRMED: 'Booking confirmed',
} as const;
