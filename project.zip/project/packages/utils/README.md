# @tennis-platform/utils

Shared utility functions for the Tennis Platform.

## Features

- Input validators (email, phone, password, etc.)
- Formatters (currency, date, time, etc.)
- Helper functions (permissions, time slots, etc.)
- Constants and enums
- Common utilities

## Installation

```bash
npm install
npm run build
```

## Usage

### Validators

```typescript
import { isValidEmail, isValidPhoneNumber, isValidPassword } from '@tennis-platform/utils';

isValidEmail('test@example.com'); // true
isValidPhoneNumber('+1234567890'); // true
isValidPassword('SecurePass123'); // true
```

### Formatters

```typescript
import { formatCurrency, formatDate, formatDateTime } from '@tennis-platform/utils';

formatCurrency(1500); // "$1,500.00"
formatDate(new Date(), 'short'); // "11/23/2025"
formatDateTime(new Date()); // "Nov 23, 2025, 03:00 PM"
```

### Helpers

```typescript
import { hasPermission, calculateAge, isTimeSlotAvailable } from '@tennis-platform/utils';

hasPermission(UserRole.Coach, UserRole.Player); // true
calculateAge('1990-01-01'); // 35
isTimeSlotAvailable(bookings, newStart, newEnd); // true/false
```

### Constants

```typescript
import { API_ENDPOINTS, ERROR_MESSAGES, PAGINATION_DEFAULTS } from '@tennis-platform/utils';

console.log(API_ENDPOINTS.AUTH.LOGIN); // "/auth/login"
console.log(ERROR_MESSAGES.UNAUTHORIZED); // "You are not authorized..."
console.log(PAGINATION_DEFAULTS.LIMIT); // 10
```

## Available Utilities

### Validators
- `isValidEmail(email)` - Validate email format
- `isValidPhoneNumber(phone)` - Validate phone number
- `isValidPassword(password)` - Check password strength
- `isValidUrl(url)` - Validate URL format
- `isValidPostalCode(code, country)` - Validate postal code
- `isValidRating(rating)` - Check rating range (1-5)
- `isValidSkillRating(rating)` - Check skill rating (0-10)

### Formatters
- `formatCurrency(amount, currency)` - Format money values
- `formatDate(date, format)` - Format dates
- `formatDateTime(date)` - Format date with time
- `formatDuration(minutes)` - Format time duration
- `formatName(firstName, lastName)` - Format full name
- `formatPhoneNumber(phone)` - Format phone display
- `truncateText(text, maxLength)` - Truncate long text
- `formatRating(rating, decimals)` - Format rating display

### Helpers
- `hasPermission(userRole, requiredRole)` - Check role permissions
- `isAdmin(userRole)` - Check if user is admin
- `isSuperAdmin(userRole)` - Check if super admin
- `calculateAge(dateOfBirth)` - Calculate age from DOB
- `calculateDuration(start, end)` - Calculate time difference
- `generateTimeSlots(start, end, interval)` - Generate available slots
- `isTimeSlotAvailable(bookings, start, end)` - Check slot availability
- `sortByDate(items, order)` - Sort by date
- `groupBy(array, key)` - Group array by key
- `debounce(func, wait)` - Debounce function calls
- `generateSlug(text)` - Generate URL-friendly slug

### Constants
- `DATE_FORMATS` - Common date format patterns
- `REGEX_PATTERNS` - Regular expressions
- `PAGINATION_DEFAULTS` - Default pagination values
- `RATING_RANGE` - Min/max rating values
- `BOOKING_DURATION` - Booking time constraints
- `API_ENDPOINTS` - API route constants
- `ERROR_MESSAGES` - Standard error messages
- `SUCCESS_MESSAGES` - Standard success messages

## Development

```bash
# Build utilities
npm run build

# Watch mode
npm run dev
```
