import { TournamentStatus, MatchStatus } from './enums';
import { PlayerProfile } from './user.types';
import { Club, Court } from './club.types';

export interface Tournament {
  id: string;
  name: string;
  description?: string;
  clubId: string;
  startDate: string;
  endDate: string;
  registrationDeadline: string;
  maxParticipants?: number;
  entryFee?: number;
  prizePool?: number;
  status: TournamentStatus;
  rules?: any;
  club?: Club;
  participants?: TournamentParticipant[];
  matches?: Match[];
  createdAt: string;
  updatedAt?: string;
}

export interface TournamentParticipant {
  id: string;
  tournamentId: string;
  playerId: string;
  registrationDate: string;
  seedNumber?: number;
  player?: PlayerProfile;
  tournament?: Tournament;
  createdAt: string;
}

export interface Match {
  id: string;
  tournamentId?: string;
  player1Id: string;
  player2Id: string;
  courtId?: string;
  scheduledTime?: string;
  status: MatchStatus;
  player1Score?: any;
  player2Score?: any;
  winnerId?: string;
  notes?: string;
  player1?: PlayerProfile;
  player2?: PlayerProfile;
  court?: Court;
  tournament?: Tournament;
  createdAt: string;
  updatedAt?: string;
}

export interface CreateTournamentData {
  name: string;
  description?: string;
  clubId: string;
  startDate: string;
  endDate: string;
  registrationDeadline: string;
  maxParticipants?: number;
  entryFee?: number;
  prizePool?: number;
  rules?: any;
}

export interface CreateMatchData {
  tournamentId?: string;
  player1Id: string;
  player2Id: string;
  courtId?: string;
  scheduledTime?: string;
}

export interface UpdateMatchData {
  scheduledTime?: string;
  status?: MatchStatus;
  player1Score?: any;
  player2Score?: any;
  winnerId?: string;
  notes?: string;
}
