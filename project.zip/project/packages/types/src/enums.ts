export enum UserRole {
  Player = 'Player',
  Coach = 'Coach',
  ClubAdmin = 'ClubAdmin',
  SuperAdmin = 'SuperAdmin',
}

export enum BookingStatus {
  Pending = 'Pending',
  Confirmed = 'Confirmed',
  Completed = 'Completed',
  Cancelled = 'Cancelled',
}

export enum CourtSurface {
  Hard = 'Hard',
  Clay = 'Clay',
  Grass = 'Grass',
  Carpet = 'Carpet',
}

export enum MatchStatus {
  Scheduled = 'Scheduled',
  InProgress = 'InProgress',
  Completed = 'Completed',
  Cancelled = 'Cancelled',
}

export enum TournamentStatus {
  Draft = 'Draft',
  Registration = 'Registration',
  InProgress = 'InProgress',
  Completed = 'Completed',
  Cancelled = 'Cancelled',
}

export enum SkillLevel {
  Beginner = 'Beginner',
  Intermediate = 'Intermediate',
  Advanced = 'Advanced',
  Professional = 'Professional',
}

export enum Gender {
  Male = 'Male',
  Female = 'Female',
  Other = 'Other',
}
