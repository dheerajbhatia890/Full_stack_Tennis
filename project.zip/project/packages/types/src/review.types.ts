import { User, CoachProfile } from './user.types';

export interface Review {
  id: string;
  coachId: string;
  playerId: string;
  rating: number;
  comment?: string;
  coach?: CoachProfile;
  player?: User;
  createdAt: string;
  updatedAt?: string;
}

export interface CreateReviewData {
  coachId: string;
  playerId: string;
  rating: number;
  comment?: string;
}

export interface UpdateReviewData {
  rating?: number;
  comment?: string;
}
