import { CourtSurface } from './enums';
import { User } from './user.types';

export interface Club {
  id: string;
  name: string;
  description?: string;
  address: string;
  city: string;
  state?: string;
  country: string;
  postalCode?: string;
  phoneNumber?: string;
  email?: string;
  website?: string;
  adminUserId: string;
  amenities?: string[];
  operatingHours?: any;
  imageUrls?: string[];
  admin?: User;
  courts?: Court[];
  createdAt: string;
  updatedAt?: string;
}

export interface Court {
  id: string;
  clubId: string;
  name: string;
  courtNumber: string;
  surface: CourtSurface;
  isIndoor: boolean;
  hourlyRate?: number;
  isActive: boolean;
  club?: Club;
  createdAt: string;
  updatedAt?: string;
}

export interface CreateClubData {
  name: string;
  description?: string;
  address: string;
  city: string;
  state?: string;
  country: string;
  postalCode?: string;
  phoneNumber?: string;
  email?: string;
  website?: string;
  adminUserId: string;
  amenities?: string[];
  operatingHours?: any;
}

export interface CreateCourtData {
  clubId: string;
  name: string;
  courtNumber: string;
  surface: CourtSurface;
  isIndoor: boolean;
  hourlyRate?: number;
}
