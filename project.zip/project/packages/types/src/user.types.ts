import { UserRole, Gender, SkillLevel } from './enums';

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  roles?: UserRole[];
  onboardingCompleted?: boolean;
  phoneNumber?: string;
  dateOfBirth?: string;
  gender?: Gender;
  profileImageUrl?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface PlayerProfile {
  id: string;
  userId: string;
  skillLevel: SkillLevel;
  rating?: number;
  bio?: string;
  preferredHand?: 'Left' | 'Right' | 'Ambidextrous';
  location?: string;
  user?: User;
  createdAt: string;
  updatedAt?: string;
}

export interface CoachProfile {
  id: string;
  userId: string;
  bio: string;
  hourlyRate: number;
  yearsOfExperience: number;
  certifications?: string[];
  specialties?: string[];
  availability?: any;
  location?: string;
  rating?: number;
  totalReviews?: number;
  user?: User;
  createdAt: string;
  updatedAt?: string;
}

export interface AuthResponse {
  user: User;
  token: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  phoneNumber?: string;
  dateOfBirth?: string;
  gender?: Gender;
}
