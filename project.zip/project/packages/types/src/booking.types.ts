import { BookingStatus } from './enums';
import { PlayerProfile, CoachProfile } from './user.types';
import { Court } from './club.types';

export interface Booking {
  id: string;
  playerId: string;
  coachId?: string;
  courtId?: string;
  startTime: string;
  endTime: string;
  status: BookingStatus;
  totalAmount?: number;
  notes?: string;
  player?: PlayerProfile;
  coach?: CoachProfile;
  court?: Court;
  createdAt: string;
  updatedAt?: string;
}

export interface CreateBookingData {
  playerId: string;
  coachId?: string;
  courtId?: string;
  startTime: string;
  endTime: string;
  notes?: string;
}

export interface UpdateBookingData {
  startTime?: string;
  endTime?: string;
  status?: BookingStatus;
  notes?: string;
}

export interface BookingFilter {
  playerId?: string;
  coachId?: string;
  courtId?: string;
  status?: BookingStatus;
  startDate?: string;
  endDate?: string;
}
