# @tennis-platform/types

Shared TypeScript types and interfaces for the Tennis Platform.

## Features

- User roles and authentication types
- Player and Coach profile interfaces
- Club and Court types
- Booking management types
- Tournament and Match types
- Review system types
- API response types
- Comprehensive enums

## Installation

```bash
npm install
npm run build
```

## Usage

```typescript
import {
  UserRole,
  User,
  CoachProfile,
  Booking,
  Tournament,
  ApiResponse
} from '@tennis-platform/types';

// Use the types in your application
const user: User = {
  id: '123',
  email: 'john@example.com',
  firstName: 'John',
  lastName: 'Doe',
  role: UserRole.Player,
  createdAt: new Date().toISOString()
};
```

## Available Types

### Enums
- `UserRole` - Player, Coach, ClubAdmin, SuperAdmin
- `BookingStatus` - Pending, Confirmed, Completed, Cancelled
- `CourtSurface` - Hard, Clay, Grass, Carpet
- `MatchStatus` - Scheduled, InProgress, Completed, Cancelled
- `TournamentStatus` - Draft, Registration, InProgress, Completed, Cancelled
- `SkillLevel` - Beginner, Intermediate, Advanced, Professional
- `Gender` - Male, Female, Other

### Interfaces
- User types: `User`, `PlayerProfile`, `CoachProfile`
- Club types: `Club`, `Court`
- Booking types: `Booking`, `CreateBookingData`, `UpdateBookingData`
- Tournament types: `Tournament`, `Match`, `TournamentParticipant`
- Review types: `Review`, `CreateReviewData`
- API types: `ApiResponse`, `PaginatedResponse`, `SearchParams`

## Development

```bash
# Build types
npm run build

# Watch mode
npm run dev
```
