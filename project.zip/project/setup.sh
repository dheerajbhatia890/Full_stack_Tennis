#!/bin/bash

echo "========================================"
echo "Tennis Platform - Setup Script"
echo "========================================"
echo ""

echo "[1/4] Installing backend dependencies..."
cd apps/backend
npm install
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install backend dependencies"
    exit 1
fi
cd ../..
echo ""

echo "[2/4] Installing web dependencies..."
cd apps/web
npm install
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install web dependencies"
    exit 1
fi
cd ../..
echo ""

echo "[3/4] Installing packages dependencies..."
cd packages/types
npm install
cd ../config
npm install
cd ../utils
npm install
cd ../..
echo ""

echo "[4/4] Building shared packages..."
cd packages/types
npm run build
cd ../config
npm run build
cd ../utils
npm run build
cd ../..
echo ""

echo "========================================"
echo "Setup Complete!"
echo "========================================"
echo ""
echo "You can now run:"
echo "  - npm run backend:dev   (Start backend server)"
echo "  - npm run web:dev       (Start web frontend)"
echo ""
